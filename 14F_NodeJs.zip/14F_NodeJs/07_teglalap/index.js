/*
npm init
npm install express
npm install ejs

- public  -> statikus fájlok
-- css
-- img

- views
-- pages  -> menüpontok sablonok
-- partials -> közös sablonok (pl.: fejléc)

*/

const express = require('express');
const app = express();
const port = 3000;
const bodyParser = require('body-parser'); // ez kezeli a post-tal elküldött http body-t

let aOldal;
let bOldal;

app.set('view engine', 'ejs');  // ejs sablon kezelő betöltése
app.use('/public',express.static(__dirname+'/public'));
app.use(bodyParser.urlencoded({extended: false}));

const menu = [
    {
        name: 'Nyitó oldal',
        url: '/'
    },
    {
        name:'Téglalap',
        url:'/teglalap'
    },
   
];

app.get('/', (req,res)=>{
    let data ={
        title: 'Nyitó oldal',
        menu: menu,
        url: req.url
    };
    res.render('pages/index',data);
});

// 1. lépés - űrlap betöltése
app.get('/teglalap', (req,res)=>{
    let data ={
        title: 'Téglalap',
        menu: menu,
        url: req.url
    };
    res.render('pages/rectangle',data);
});

// 2. elküldött adatok leszedése
app.post('/teglalap', (req,res)=>{
    aOldal = req.body.aoldal;
    bOldal = req.body.boldal;
    // console.log('A oldal:',aOldal);
    // console.log('B oldal:',bOldal);
    res.redirect('/eredmeny'); //  átirányítás - /eredmény url-t meghívja GET metódussal
});

// 3. eredmény megjelnítése
app.get('/eredmeny',(req,res)=>{
    let result = {
        t: aOldal*bOldal,
        k: 2*(aOldal+bOldal)
    }
    //console.log(result);
    let data ={
        title: 'Téglalap',
        menu: menu,
        result: result,
        url: req.url
    };
    res.render('pages/result',data)
})

app.listen(port,()=>{ 
    console.log(`App listening at http://localhost:${port}`);
 });

