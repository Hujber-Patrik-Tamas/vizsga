/*
npm init
npm install express
npm install ejs
npm install body-parser

- public  -> statikus fájlok
-- css
-- img

- views
-- pages  -> menüpontok sablonok
-- partials -> közös sablonok (pl.: fejléc)

npm install  -> létrehozza a node_modules mappát
npx nodemon index.js
*/

const express = require('express');
const app = express();
const port = 3000;
const bodyParser = require('body-parser'); // ez kezeli a post-tal elküldött http body-t

app.set('view engine', 'ejs');  // ejs sablon kezelő betöltése
app.use('/public',express.static(__dirname+'/public'));
app.use(bodyParser.urlencoded({extended: true}));

let tippek=[]; // én tippjeim
let szamok=[]; // véletlen számok
let talalat=0; 

const menu = [
    {
        name: 'Nyitó oldal',
        url: '/'
    },
    {
        name: 'Tippek',
        url: '/tippek'
    },
];

app.get('/', (req,res)=>{
    let data ={
        title: 'Nyitó oldal',
        menu: menu,
        url: req.url
    };
    res.render('pages/index',data);
});

app.get('/tippek', (req,res)=>{
    let data ={
        title: 'Nyitó oldal',
        menu: menu,
        url: req.url
    };
    res.render('pages/tippek',data);
});
app.post('/tippek', (req,res)=>{
   tippek = req.body.tippek;
   //console.log(tippek);
   res.redirect('/result');
   //res.send();
});
app.get('/result',(req,res)=>{
    lottoHuzas();
    //console.log('szamok',szamok);
    tippEllenorzes();
    //console.log('tippek',tippek)
    let data ={
        title: 'Nyitó oldal',
        menu: menu,
        url: req.url,
        szamok : szamok,
        talalat : talalat
    };
    res.render('pages/result',data);
})

function lottoHuzas(){
    szamok=[]; // üres tömb
    while (szamok.length <5){
        let randomNumber = Math.floor(Math.random()*10)+1;  // 1 és 90 között gen. véletlen számot
        if (!szamok.includes(randomNumber)) szamok.push(randomNumber);
    }
}

function tippEllenorzes(){
    talalat=0;
    tippek.forEach(tip =>{
        if (szamok.includes(+tip)) talalat++;
        // + jel számmá konvertálja a változót
    });
}

app.listen(port,()=>{ 
    console.log(`App listening at http://localhost:${port}`);
 });

