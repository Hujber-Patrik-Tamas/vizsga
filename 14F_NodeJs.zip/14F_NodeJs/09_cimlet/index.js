/*
npm init
npm install express
npm install ejs
npm install body-parser

- public  -> statikus fájlok
-- css
-- img

- views
-- pages  -> menüpontok sablonok
-- partials -> közös sablonok (pl.: fejléc)

npm install  -> létrehozza a node_modules mappát
*/

const express = require('express');
const app = express();
const port = 3000;
const bodyParser = require('body-parser'); // ez kezeli a post-tal elküldött http body-t
const { escapeRegExpChars } = require('ejs/lib/utils');

app.set('view engine', 'ejs');  // ejs sablon kezelő betöltése
app.use('/public',express.static(__dirname+'/public'));
app.use(bodyParser.urlencoded({extended: true}));

let osszeg;

// 1. 
app.get('/', (req,res)=>{
    let data = {
        title: 'Címletezés',
    };
    res.render('pages/index',data);
});
// 2.
app.post('/cimlet', (req,res)=>{
    osszeg = parseInt(req.body.osszeg);
    res.redirect('/eredmeny');
});
// 3.
app.get('/eredmeny', (req,res)=>{
    let cimletek=[20000,10000,5000,2000,1000,500,200,100,50,20,10,5];
    let cimletekreBontva=[];
    let osszeg_orig = osszeg;  // elmentem az osszeg változót
    // kerekítés
    let kerekites = 0;
    if (osszeg % 5 == 1) kerekites=-1; 
    if (osszeg % 5 == 2) kerekites=-2; 
    if (osszeg % 5 == 3) kerekites=+2; 
    if (osszeg % 5 == 4) kerekites=+1; 

    osszeg = osszeg + kerekites;

    //console.log(osszeg);
    cimletek.forEach(egyCimlet => {
        cimletekreBontva.push(parseInt(osszeg/egyCimlet));
        osszeg = osszeg % egyCimlet;
    });

    // for (let index = 0; index < cimletek.length; index++) {
    //     cimletekreBontva[index] = parseInt(osszeg/cimletek[index]);
    //     osszeg = osszeg % cimletek[index];
    // }

    //console.log(cimletekreBontva);

    let data = {
        title: 'Címletezés',
        osszeg: osszeg_orig,
        cimletek: cimletek,
        cimletekreBontva: cimletekreBontva
    };
    res.render('pages/result',data);
});

app.listen(port,()=>{ 
    console.log(`App listening at http://localhost:${port}`);
 });

