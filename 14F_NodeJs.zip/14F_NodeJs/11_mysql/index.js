/*
npm init
npm install express  // javascript szerver
npm install ejs      // sablon kezelő
npm install body-parser // űrlap feldolgozó

npm install mysql  // MySql kezelés

*/

const express = require('express');
const app = express();
const port = 3000;
const bodyParser = require('body-parser');
const mysql = require('mysql');

const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: '14f_world'
});

con.connect((err)=>{
    if (err) throw err;  // hiba esetén leáll a program 
    console.log('Connected');
});

app.set('view engine','ejs');

app.use('/public',express.static(__dirname+'/public'));
app.use(bodyParser.urlencoded({extended:true}));
/*
A kiterjesztett opció lehetővé teszi, hogy az URL-kódolt adatokat a querystring könyvtárral (ha hamis) vagy a qs könyvtárral (ha igaz) elemezzük.
A "kiterjesztett" szintaxis lehetővé teszi, hogy  objektumok és tömbök kódolhatók legyenek az URL-kódolt formátumba, JSON-szerű URL-kódolással. 
*/


app.get('/',(req,res)=>{
    //res.end('ok');
    con.query('select * from countries',(error,rows)=>{
        if (error){
            res.redirect('/error');
           // res.end();
        } else {
            let data={
                rows: rows
            };
            res.render('pages/index',data);
        }

    });
});

app.get('/country-details/:id', (req,res)=>{
    let id = req.params.id;
    //console.log(id);
    con.query(`select * from countries where id=${id}`,(error,rows)=>{
        if (error){
            res.redirect('/error');
        }
        if (rows.length === 0){
            // hiba kezelés

        } else {
            let data ={
                row: rows[0]
            }
            res.render('pages/country-details',data);
        }
    })
   
});

app.get('/cities', (req,res)=>{
    let data = {
        rows: [],
        city:'',
        error: false
    }
    res.render('pages/cities',data);
});
app.post('/cities', (req,res)=>{
    let city = req.body.city;
    //console.log(city)
    let sql='select * from cities where name like ?'; // ? egy paraméter
    
    con.query(sql,'%'+city+'%',(error,rows)=>{
        if (error){
            res.redirect('/error');
        }
        if (rows.length == 0){
            let data = {
                rows: rows,
                city: city,
                error: true
            }
            res.render('pages/cities',data);
        } else {
            let data ={
                rows: rows,
                city: city,
                error:false
            }
            res.render('pages/cities',data);
        }
    });
});

app.get('/states',async (req,res)=>{
    // con.query('SELECT * FROM countries ORDER BY name',(error,rows)=>{
    //     let data = {
    //         rows: rows,
    //         rowsState:[],
    //         currentCountry: 1
    //     }
    //     res.render('pages/states',data);
    // });
    let data = {
        rows: await allCountry(),
        rowsState: [],
        currentCountry: 1
    }
    res.render('pages/states',data);
})

app.post('/states',async (req,res)=>{
    let countryId = req.body.countryid;
    let data = {
        rows: await allCountry(),
        rowsState: await statesByCountry(countryId),
        currentCountry: countryId
    }
    res.render('pages/states',data);
});

app.get('/world', async (req,res)=>{
    let data = {
        countries: await allCountry()
    }
    res.render('pages/world',data);
})
app.get('/world/states/:countryid/:countryname', async (req,res)=>{
    let data = {
        states: await statesByCountry(req.params.countryid),
        countryName : req.params.countryname
    }
    res.render('pages/worldstate',data);
})
app.get('/world/city/:stateid/:countryname/:statename', async (req,res)=>{
    let data = {
        countryName : req.params.countryname,
        stateName : req.params.statename,
        cities: await citiesByState(req.params.stateid)
    }
    res.render('pages/worldcities',data);
})
function allCountry(){
    const sql='SELECT * FROM countries ORDER BY name';
    return new Promise((resolve,reject)=>{
        con.query(sql,(error,rows)=>{
            resolve(rows);
        });
    });
}
function statesByCountry(countryId){
    const sql = 'SELECT * FROM states WHERE country_id=?';
    return new Promise((resolve,reject)=>{
        con.query(sql,countryId, (error,rows)=>{
            resolve(rows);
        })
    });
}
function citiesByState(stateId){
    const sql = 'SELECT * FROM cities WHERE state_id=?';
    return new Promise((resolve,reject)=>{
        con.query(sql,stateId, (error,rows)=>{
            resolve(rows);
        })
    });
}

app.get('/error',(req,res)=>{
    res.render('pages/error');
    //res.end('database error')
})

app.listen(port,()=>{
    console.log(`Szerver: http:\\\\localhost:${port}`);
});