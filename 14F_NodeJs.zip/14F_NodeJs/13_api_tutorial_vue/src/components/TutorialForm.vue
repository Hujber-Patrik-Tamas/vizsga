<template>
    <div class="mb-3">
        <label for="title" class="form-label">Title:</label>
        <input 
            type="text" 
            class="form-control" 
            id="title"
            v-model="tutorialData.title">
    </div>
    <div class="mb-3">
        <label for="description" class="form-label">Description:</label>
        <textarea 
            id="description" 
            cols="30" 
            rows="6" 
            class="form-control"
            v-model="tutorialData.description"
            ></textarea>
    </div>
    <div class="mb-3">
        <input 
            class="form-check-input me-2" 
            type="checkbox" 
            value="" 
            id="published"
            v-model="tutorialData.published">
        <label class="form-check-label" for="published">
            Published
        </label>
    </div>
    <div class="d-flex justify-content-between">
        <button 
            class="btn btn-primary" 
            @click="saveTutorial"
        >Save</button>
        <router-link to="/" class="btn btn-outline-primary">Back</router-link>
    </div>
</template>

<script setup>
import {useRouter} from 'vue-router';
import {useTutorialStore} from '../stores/index.js'

const props = defineProps(['tutorialData']);
const {saveNewTutorial} = useTutorialStore();

const router = useRouter();

function saveTutorial(){
    //console.log('ok');
    saveNewTutorial(props.tutorialData)
        .then(()=>{
            router.push('/');
        })
}
</script>

<style lang="scss" scoped></style>