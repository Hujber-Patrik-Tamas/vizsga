import {defineStore} from 'pinia';
import Axios from '../services/dataservice.js'

export const useTutorialStore = defineStore({
    id:'TutorialStore',
    state:()=>({
        // itt tároljuk az adatokat
        tutorials:[],
    }),
    getters:{
        // lekérdezni a state-ba lévő változókat
    },
    actions:{
        // feltöltjük a state-ban lévő változókat
        // ide kerülnek a API hívások
        getAllTutorials(){
            return Axios.get('/')
                .then(resp =>{
                    //console.log(resp.data);
                    this.tutorials = resp.data;
                })
                .catch()
        },
        saveNewTutorial(tutorialData){
            return Axios.post('/',tutorialData)
                .then(()=>{return;})
                .catch()
        }

    }
});