<script setup>
    import { storeToRefs } from 'pinia';
    import {useTutorialStore} from '../stores/index.js'

    const {getAllTutorials} = useTutorialStore();
    const {tutorials} = storeToRefs(useTutorialStore());

    getAllTutorials();
</script>

<template>
<div class="container">
    <div class="row">
        <div class="col-12">
            <h1>Tutorials</h1>
            <router-link to="/new-tutorial" class="btn btn-primary my-3">New tutorial</router-link>
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Published</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(t,index) in tutorials">
                        <td>{{ index+1 }}</td>
                        <td>{{ t.title }}</td>
                        <td>{{ t.description }}</td>
                        <td v-if="t.published">Yes</td>
                        <td v-else>No</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
</template>
