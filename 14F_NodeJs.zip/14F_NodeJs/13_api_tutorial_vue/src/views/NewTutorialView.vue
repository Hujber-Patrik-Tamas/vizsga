<template>
   <div class="container">
    <div class="col-12 col-md-6 mx-md-auto">
        <h3>New Tutorial</h3>
        <tutorial-form :tutorialData="tutorialData"/>
    </div>
   </div>
</template>

<script setup>
import { ref } from 'vue';
import TutorialForm from '../components/TutorialForm.vue'

const tutorialData = ref({
    id:null,
    title:'',
    description:'',
    published: 0
})
</script>

<style lang="scss" scoped>

</style>