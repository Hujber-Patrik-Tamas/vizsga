const connection = require('../config/db');

const Pizza = {
    // Hogy hívják az egyes pizzafutárokat?  
    getDeliveryNames(req,res){
        let sql= 'SELECT fnev FROM futar';
        connection.query(sql, (err,data) => {
            if (err){
                res.status(500).send({
                    message: err.message || "Database error"
                });
            } else {
                //res.send(data);
                res.send(data.map(x => x.fnev))
            }
        })
    },
    // Mely pizzák olcsóbbak egy adott árnál?
    getCheaper(req,res){
        let prize = req.params.prize;
        let sql= 'SELECT * FROM pizza WHERE par < ?';
        connection.query(sql,prize,(err,data) => {
            if (err){
                res.status(500).send({
                    message: err.message || "Database error"
                });
            } else {
                res.send(data);
            }
        })
    },
}

module.exports = Pizza;