module.exports = (app) =>{
    const router = require('express').Router(); // router tárolja a útvonalakat
    const pizza = require('../controllers/pizza.controller');

    router.get('/delivery-names',pizza.getDeliveryNames)
    router.get('/cheaper/:prize',pizza.getCheaper)
    
    app.use('/api',router); // default route név
}