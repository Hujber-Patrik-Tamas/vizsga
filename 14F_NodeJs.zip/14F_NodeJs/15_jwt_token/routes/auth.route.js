module.exports = (app) =>{
    const router = require('express').Router();
    const auth = require('../controllers/auth.controllers');
    const blog = require('../controllers/blog.controller.js');

    router.post('/login',auth.login);
    router.get('/blog',blog.secretBlog);

    app.use('/api',router);
}