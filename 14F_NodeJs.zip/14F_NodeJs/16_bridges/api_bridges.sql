-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2023. Ápr 14. 07:38
-- Kiszolgáló verziója: 10.4.27-MariaDB
-- PHP verzió: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `api_bridges`
--
CREATE DATABASE IF NOT EXISTS `14f_bridges` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `14f_bridges`;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `bridges`
--

CREATE TABLE `bridges` (
  `id` int(10) UNSIGNED NOT NULL,
  `bridgeName` varchar(100) NOT NULL,
  `description` varchar(3000) NOT NULL,
  `isPublicRoad` tinyint(1) NOT NULL,
  `flowKm` double(8,2) NOT NULL,
  `routes` varchar(500) NOT NULL,
  `location` int(10) UNSIGNED NOT NULL,
  `deliveryDate` date NOT NULL,
  `pictureUrl` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `bridges`
--

INSERT INTO `bridges` (`id`, `bridgeName`, `description`, `isPublicRoad`, `flowKm`, `routes`, `location`, `deliveryDate`, `pictureUrl`) VALUES
(1, 'Megyeri híd', 'A Megyeri híd (nem hivatalosan az M0-s északi Duna-hídja) közúti híd a Duna felett, mely Újpestet köti össze Budakalásszal a Szentendrei-szigeten keresztül. A híd a magyar fővárost elkerülő M0-s autóút 2. számú főút és 11. számú főút közti szakaszának része, mely áthalad a Szentendrei-sziget és a Szentendrei-Duna felett is. A híd valójában 5 híd (9 hídszerkezet) együttese, melyek közül a legnevezetesebb a Nagy-Duna-ág felett átívelő 591 m hosszú hídszerkezet, amely az ország első igazi ferdekábeles hídja.', 1, 1659.80, 'M0-s autóút észak', 3, '2008-09-30', 'http://elit.jedlik.eu/nits/bridges/01.jpg'),
(2, 'Újpesti vasúti híd', 'Az Újpesti vasúti híd (nem hivatalos nevén Északi összekötő vasúti híd) Budapest egyik vasúti Duna-hídja, amely a Népsziget felett is átvezet. A Budapest-Esztergom-vasútvonal forgalma mellett a gyalogos és a kerékpáros közlekedést is szolgálja.', 0, 1654.70, 'Budapest-Esztergom-vasútvonal', 2, '1896-11-03', 'http://elit.jedlik.eu/nits/bridges/02.jpg'),
(3, 'Árpád híd', 'Az Árpád híd Budapest egyik közúti Duna-hídja Budapest III. kerülete és Budapest XIII. kerülete között. A Megyeri híd 2008-as átadásáig a főváros leghosszabb hídja és legészakibb közúti hídja volt. Egyik különlegessége, hogy az eredetileg átadott híd bővítését úgy oldották meg, hogy két oldalt 1-1 új hidat építettek mellé, azaz az Árpád híd voltaképp három párhuzamos, egymással összekapcsolódó hídszerkezetből áll.', 1, 1651.40, 'Róbert Károly körút - Vörösvári út/Szentendrei út', 2, '1950-11-07', 'http://elit.jedlik.eu/nits/bridges/03.jpg'),
(4, 'Margit híd', 'A budapesti Margit híd a Szent István körutat és a Margit körutat köti össze a Margit-sziget érintésével. A főváros második állandó hídjaként 1872 és 1876 között épült, 1876. április 30-án avatták fel. Tervpályázatát 1871-ben írták ki, melyen az első díjat Ernest Goüin francia mérnöknek ítélték, és a Societé de Construction de Batignoles nyerte el a szerződést a híd megépítésére.', 1, 1648.80, 'Margit körút - Margit-sziget - Szent István körút', 2, '1876-04-30', 'http://elit.jedlik.eu/nits/bridges/04.jpg'),
(5, 'Széchenyi lánchíd', 'A Széchenyi lánchíd (a köznyelvben gyakran csak Lánchíd) a Buda és Pest közötti állandó összeköttetést biztosító legrégibb, legismertebb híd a Dunán, a magyar főváros egyik jelképe, egyben az első állandó híd a teljes magyarországi Duna-szakaszon. Építését gróf Széchenyi István kezdeményezte, és finanszírozását báró Sina György szervezte, a legnagyobb adományt is ő adta a klasszicista stílusban tervezett híd megépítésére.', 1, 1647.03, 'Clark Ádám tér - Széchenyi István tér', 2, '1849-11-20', 'http://elit.jedlik.eu/nits/bridges/05.jpg'),
(6, 'Erzsébet híd (új)', 'Az Erzsébet híd Budapest egyik közúti hídja a Dunán, amely az V. kerületet köti össze az I. kerülettel. Az 1903-tól ugyanezen a helyen álló (régi) Erzsébet hidat 1945 januárjában a visszavonuló német csapatok felrobbantották, a helyette épült, 10 méterrel szélesebb kábelhidat 1964-ben adták át.', 1, 1646.04, 'Hegyalja út - Rákóczi út', 2, '1964-11-21', 'http://elit.jedlik.eu/nits/bridges/06.jpg'),
(7, 'Szabadság híd', 'A Szabadság híd (korábban Ferenc József híd, Fővám téri híd) Budapest egyik, 1896-ban, a főváros harmadik közúti átkelőjeként átadott hídja, Budapest központjának legrövidebb hídja. Két végén két közterület található, a Gellért tér (a Gellért-hegy lábánál, a Gellért Gyógyfürdővel és a Hotel Gellérttel) és a Fővám tér (a Központi Vásárcsarnokkal). A híd eredetileg a millenniumi világkiállítás részeként épült, a 19. század végén, szecessziós stílusban, mely mitológiai szobrokkal és az ország címerével lett díszítve. A Szabadság hidat építették újjá legelőszőr, miután a második világháború alatt súlyos károkat szenvedett.', 1, 1645.29, 'Vámház körút - Bartók Béla út', 2, '1896-10-04', 'http://elit.jedlik.eu/nits/bridges/07.jpg'),
(8, 'Petőfi híd', 'A Petőfi híd (1937-től 1945-ig: Horthy Miklós híd) Budapest egyik Duna-hídja. 1933–37 között építették, a pesti és budai körút déli szakaszainak villamos- és gépjárműforgalmát vezeti át a Duna felett. Hossza 378 m, feljárókkal együtt 514 m. Szélessége 25,6 m. A híd pesti oldalán a Boráros tér (a Nagykörút déli végével, a H7-es HÉV végállomása), illetve a budai hídfőnél a Goldmann György tér.', 1, 1644.31, 'Irinyi út - Ferenc körút', 2, '1937-09-12', 'http://elit.jedlik.eu/nits/bridges/08.jpg'),
(9, 'Rákóczi híd', 'A Rákóczi híd Budapest második legújabb Duna-hídja, Lágymányos és Ferencváros között. Közvetlenül az Összekötő vasúti híd mellett, attól északi irányban található, a Duna 1643,1 folyamkilométerénél. Eredetileg (1995 és 2011 között) a Lágymányosi híd nevet viselte.', 1, 1643.12, 'Szerémi út - Könyves Kálmán körút', 2, '1995-10-01', 'http://elit.jedlik.eu/nits/bridges/09.jpg'),
(10, 'Összekötő vasúti híd', 'Az Összekötő vasúti híd (a köznyelvben sokszor még: Déli összekötő vasúti híd) Budapest egyik vasúti Duna-hídja. Magyarország legfontosabb és legforgalmasabb vasúti összeköttetése a Dunán, amelyen az ország áthaladó vasúti forgalmának túlnyomó része folyik. A híd közvetlenül a Rákóczi híd mellett, annak déli oldalán található.', 0, 1643.09, 'Budapest-Hegyeshalom-Rajka-vasútvonal', 2, '1877-10-23', 'http://elit.jedlik.eu/nits/bridges/10.jpg'),
(11, 'Deák Ferenc híd', 'A Deák Ferenc híd (nem hivatalosan az M0-s autóút déli Duna-hídja, de nevezik Hárosi Duna-hídnak is) Budapest legdélibb Duna-hídja, az E60, E71, E75 nemzetközi főútvonalak része. Névadója Deák Ferenc politikus.', 1, 1632.86, 'M0-s autóút dél', 4, '1990-11-16', 'http://elit.jedlik.eu/nits/bridges/11.jpg'),
(12, 'Pentele híd', 'A Pentele híd a Duna fölött átívelve Kisapostagot köti össze Dunavecsével, egyúttal a Dunántúlt az Alfölddel, illetve a 6-os számú főutat az 51-es számú főúttal. Ismert még Dunaújvárosi híd és M8 Duna-híd néven is. A hídra az említett két település közigazgatási területéről lehet fel-, illetve lehajtani. Dunaújváros közigazgatási területén mintegy 600 méter hosszan csupán áthalad.', 1, 1571.65, 'M8-as autópálya', 6, '2007-07-23', 'http://elit.jedlik.eu/nits/bridges/12.jpg'),
(13, 'Beszédes József híd', 'A Beszédes József híd Dunaföldvárnál köti össze a Dunántúlt az Alfölddel. A köznyelv hívja még dunaföldvári vagy egyszerűen földvári hídnak is. A hídnyílás magassága 8,85 méter, a hajózható hídnyílás szélessége 74 méter.', 1, 1560.56, '52-es főút', 5, '1930-11-23', 'http://elit.jedlik.eu/nits/bridges/13.jpg'),
(14, 'Szent László híd', 'A Szent László híd Szekszárdtól északra köti össze a Dunántúlt az Alfölddel. A köznyelv hívja még szekszárdi hídnak is. A hídnyílás magassága 9,5 méter, a hajózható hídnyílás szélessége 100 méter. Két ártéri hídból és egy 80 m+3x120 m+80 m nyílásközű, 520,5 m hosszú mederhídból áll. Az ártéri hidak támaszközei 3x65,5 m-esek.', 1, 1498.79, 'M9-es autóút', 7, '2003-07-04', 'http://elit.jedlik.eu/nits/bridges/14.jpg'),
(15, 'Türr István híd', 'A bajai Türr István híd Bajánál biztosít közúti és vasúti kapcsolatot a Dunántúl és a Duna-Tisza-köze között. A legdélebbi magyarországi Duna-híd. Gyakran csak „bajai hídnak” nevezik. 1921. november 1-jén a híd bal parti hídfőjénél szállt hajóra, és ment végleg száműzetésbe az utolsó magyar király, IV. Károly.', 1, 1480.19, '55-ös főút és Bátaszék-Baja-Kiskunhalas-vasútvonal', 1, '2003-07-04', 'http://elit.jedlik.eu/nits/bridges/15.jpg');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `locations`
--

CREATE TABLE `locations` (
  `id` int(10) UNSIGNED NOT NULL,
  `locationName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `locations`
--

INSERT INTO `locations` (`id`, `locationName`) VALUES
(1, 'Baja-Pörböly'),
(2, 'Budapest'),
(3, 'Budapest-Dunakeszi'),
(4, 'Budapest-Szigetszentmiklós'),
(5, 'Dunaföldvár-Solt'),
(6, 'Dunaújváros-Dunavecse'),
(7, 'Szekszárd-Dusnok');

-- --------------------------------------------------------


--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `bridges`
--
ALTER TABLE `bridges`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `bridges_bridgename_unique` (`bridgeName`),
  ADD UNIQUE KEY `bridges_flowkm_unique` (`flowKm`),
  ADD KEY `bridges_location_foreign` (`location`);

--
-- A tábla indexei `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `locations_locationname_unique` (`locationName`);


--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `bridges`
--
ALTER TABLE `bridges`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT a táblához `locations`
--
ALTER TABLE `locations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `bridges`
--
ALTER TABLE `bridges`
  ADD CONSTRAINT `bridges_location_foreign` FOREIGN KEY (`location`) REFERENCES `locations` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
