const mysql = require('mysql');

const connection = mysql.createPool({
    host: '127.0.0.1',
    user: 'root',
    password: '',
    database: '14f_bridges',
    dateStrings: true //így lesz jó a dátum formátum
});

module.exports = connection;
