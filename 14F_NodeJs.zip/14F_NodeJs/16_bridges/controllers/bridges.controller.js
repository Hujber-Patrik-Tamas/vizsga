const connection = require('../config/db');

const Bridges = {
    getBridgesOrderByField(req,res){
        //console.log('ok');
        // SELECT * FROM bridges INNER JOIN locations ON bridges.location = locations.id ORDER BY brigdeName ASC;
        const sql = 'SELECT bridges.*,locations.id AS lid,locations.locationName FROM bridges INNER JOIN locations ON bridges.location = locations.id ORDER BY ' + req.params.field + ' ' + req.params.direction;
        //console.log(sql);
        connection.query(sql, (err,data)=>{
            if (err){
                res.status(400).send(
                    {
                        message: err.message
                    }
                );
            } else {
                res.status(200).send(data);
            }
        });
    },
    insertBridge(req,res){

        const date1 = new Date(); // mai dátum
        const date2 = new Date(req.body.deliveryDate);

        // console.log(date1,date2);
        if (date1 < date2) {
            // hibás dátum
            res.status(400).send(
                {
                    message: "Az aktuális dátumnál nem adhat meg későbbi dátumot a deliveryDate mezőben!" 
                }
            );
            return;
        }

        const newBridge = {
            bridgeName: req.body.bridgeName,
            description: req.body.description,
            isPublicRoad: req.body.isPublicRoad,
            flowKm: req.body.flowKm,
            routes: req.body.routes,
            location: req.body.location,
            deliveryDate: req.body.deliveryDate,
            pictureUrl: req.body.pictureUrl
        }
        console.log(newBridge);
        const sql ='insert into bridges set ?';
        connection.query(sql,newBridge,(err,data)=>{
            if (err){
                res.status(400).send(
                    {
                        message: err.message
                    }
                );
            } else {
                res.status(201).send();
            }
        })

    },

    updateBridge(req,res){
        //console.log('ok');
        //console.log(req.params.id);
        //console.log(req.body);
        const sql = 'update bridges set ? WHERE id = ?';
        connection.query(sql,[req.body,Number(req.params.id)],(err,data)=>{
            if (err){
                res.status(400).send(
                    {
                        message: err.message
                    }
                );
                return; // kilépés a fv-ből hiba esetén
            }

            if (data.affectedRows == 0){
                // affectedRows -> módosított rekordok száma
                res.status(404).send({
                    message : `A híd ${req.params.id} azonosítóval nem létezik!` 
                });
                return;
            }
            // nincs hiba
            connection.query('select * from bridges where id = '+Number(req.params.id),(err,data)=>{
                res.send(data);
            })
        })
    }
}

module.exports = Bridges;