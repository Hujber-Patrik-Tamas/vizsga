module.exports = (app) =>{
    const router = require('express').Router(); // router tárolja a útvonalakat
    const Bridges = require('../controllers/bridges.controller');

    router.get('/danube/bridges/:field/:direction',Bridges.getBridgesOrderByField);
    router.post('/danube/bridges',Bridges.insertBridge);
    router.patch('/danube/bridges/:id',Bridges.updateBridge);

    app.use('/api',router); // default route név
}