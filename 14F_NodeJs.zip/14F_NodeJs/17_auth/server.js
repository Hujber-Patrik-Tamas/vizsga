const express = require('express');
const session = require('express-session');
    
const app = express()

app.use(session({
    secret: '2C44-4D44-WppQ38S',
    resave: true,
    saveUninitialized: true
}));

const cors = require('cors');
const corsOptions = {
  origin: 'http://127.0.0.1:5173',
  credentials: true
}
app.use(cors(corsOptions));

app.use(express.json()); // json formátum beállítás
app.use(express.urlencoded({extended: true}));

// Authentication and Authorization Middleware
var auth = function(req, res, next) {
  console.log(req.session.email);
  if (req.session && req.session.email === "a" && req.session.admin)
    return next();
  else
    return res.sendStatus(401);
};
 
// Login endpoint
app.post('/api/login', function (req, res) {
 
  // if (!req.query.username || !req.query.password) {
  //   res.send('login failed');    
  // } else if(req.query.username === "amy" || req.query.password === "amyspassword") {
  //   req.session.user = "amy";
  //   req.session.admin = true;
  //   res.send("login success!");
  // }

  if (!req.body.email || !req.body.password) {
    res.send('login failed');    
  } else if(req.body.email === "a" && req.body.password === "a") {
    req.session.email = req.body.email;
    req.session.admin = true;
    res.send({message:"login success!"});
  } else {
    res.status(401).send({message:"login faild!"});
  }
});
 
// Logout endpoint
app.get('/api/logout', function (req, res) {
  req.session.destroy();
  res.send("logout success!");
});
 
// Get content endpoint
app.get('/api/content', auth, function (req, res) {
    res.send({message:"Secret info!"});
});
 
app.listen(3000);
console.log("app running at http://localhost:3000");