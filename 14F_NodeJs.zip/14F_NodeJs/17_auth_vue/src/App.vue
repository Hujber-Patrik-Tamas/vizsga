<script setup>
import { ref ,computed} from 'vue';
import {useAuthStore} from './stores/auth.js';
import { storeToRefs } from 'pinia'

const {isLoggedIn} = storeToRefs(useAuthStore());
console.log('i',isLoggedIn.value);
const menuVisible = computed(()=>{
  return isLoggedIn.value;
});
  


</script>

<template>
  <RouterLink to="/">Home</RouterLink> 
  <RouterLink v-if="!menuVisible" to="/login">Login</RouterLink> 
  <RouterLink v-if="menuVisible" to="/protected">Protected</RouterLink> 
  <RouterLink to="/about">About</RouterLink> 
  <RouterLink v-if="menuVisible" to="/logout">Logout</RouterLink>
  <RouterView />
</template>

<style scoped>
a {
  margin-left: 10px;
}
</style>
