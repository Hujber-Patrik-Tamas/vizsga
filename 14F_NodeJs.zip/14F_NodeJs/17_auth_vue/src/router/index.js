import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import LoginView from '../views/LoginView.vue'
import ProtectedView from '../views/ProtectedView.vue'
import LogoutView from '../views/LogoutView.vue'

import axios from 'axios'
import {useAuthStore} from '../stores/auth.js'
import { storeToRefs } from 'pinia'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView
    },
    {
      path: '/login',
      component: LoginView
    },
    {
      path: '/protected',
      component: ProtectedView
    },
    {
      path: '/logout',
      component: LogoutView
    },
    {
      path: '/about',
      name: 'about',
      // route level code-splitting
      // this generates a separate chunk (About.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import('../views/AboutView.vue')
    }
  ]
})

router.beforeEach((to,from,next)=>{
 
  const {isLoggedIn} = storeToRefs(useAuthStore())
  const publicPage = ['/','/login','/about','/logout']
  const autRequired = !publicPage.includes(to.path)
  
 console.log(autRequired,isLoggedIn.value);
 
  if (autRequired && !isLoggedIn.value){
    return next('/login')
  } else{
    next() 
  }
 
})

export default router
