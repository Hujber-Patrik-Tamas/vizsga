
import { defineStore } from 'pinia'

export const useAuthStore = defineStore({
  id:'auth',
  state: ()=>({
    email:'',
    isLoggedIn:false
  }),
  actions:{
    storeLoginData(email){
      if (email != ''){
        this.email = email;
        this.isLoggedIn = true;
      } else {
        this.email = '';
        this.isLoggedIn = false;
      }
    },
    logout(){
      this.email = '';
      this.isLoggedIn = false;
      console.log('ok');
    }
  }
});
