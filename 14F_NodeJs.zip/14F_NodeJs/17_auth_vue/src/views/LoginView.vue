<template>
  <h1>Login</h1>
  <form>
    <div>
      <label>E-mail:</label>
      <input type="email" name=""  v-model="loginData.email">
    </div>
    <div>
      <label>Password:</label>
      <input type="password" name="" v-model="loginData.password">
    </div>
    <button @click="login">Login</button>
  </form>
</template>

<script setup>
import axios from 'axios';
import { ref } from 'vue';
import {useAuthStore} from '../stores/auth.js';
import { useRouter } from 'vue-router';

const {storeLoginData} = useAuthStore()

const router = useRouter();

const loginData = ref({
  email:'',
  password:''
});
function login(){
  axios.defaults.withCredentials = true;
  axios.post('/api/login',loginData.value)
    .then(resp =>{
      console.log(resp);
      storeLoginData(loginData.value.email)
      router.push('/protected')
    })
    .catch(err => {
      console.log(err);
      storeLoginData('')
    })
}
</script>

<style lang="scss" scoped></style>