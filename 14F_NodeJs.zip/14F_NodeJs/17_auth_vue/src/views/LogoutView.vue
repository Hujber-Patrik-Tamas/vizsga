<template>
  
</template>

<script setup>
import {useAuthStore} from '../stores/auth.js';
import { useRouter } from 'vue-router';
import axios  from 'axios'

const router = useRouter();
const {logout} = useAuthStore();

logout();

axios.get('/api/logout')

router.push('/')
</script>

<style lang="scss" scoped>

</style>