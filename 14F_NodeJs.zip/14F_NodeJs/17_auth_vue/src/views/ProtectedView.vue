<template>
  <h1>Protected</h1>
  {{ message }}
</template>

<script setup>
import axios from 'axios';
import { ref } from 'vue';

const message = ref();

//axios.defaults.withCredentials = true;
axios.get('/api/content')
  .then(resp =>{
    message.value = resp.data
  })
  .catch(err =>{
    console.log(err);
  })
</script>

<style lang="scss" scoped>

</style>