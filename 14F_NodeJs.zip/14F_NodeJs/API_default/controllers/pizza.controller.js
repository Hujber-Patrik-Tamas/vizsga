const connection = require('../config/db');

const Pizza = {

}

module.exports = Pizza;