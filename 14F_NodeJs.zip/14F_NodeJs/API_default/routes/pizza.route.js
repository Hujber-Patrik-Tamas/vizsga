module.exports = (app) =>{
    const router = require('express').Router(); // router tárolja a útvonalakat
    const pizza = require('../controllers/pizza.controller');


    
    app.use('/api',router); // default route név
}