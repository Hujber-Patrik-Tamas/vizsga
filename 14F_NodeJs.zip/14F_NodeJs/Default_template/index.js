/*
npm init
npm install express
npm install ejs
npm install body-parser

- public  -> statikus fájlok
-- css
-- img

- views
-- pages  -> menüpontok sablonok
-- partials -> közös sablonok (pl.: fejléc)

npm install  -> létrehozza a node_modules mappát
*/

const express = require('express');
const app = express();
const port = 3000;
const bodyParser = require('body-parser'); // ez kezeli a post-tal elküldött http body-t

app.set('view engine', 'ejs');  // ejs sablon kezelő betöltése
app.use('/public',express.static(__dirname+'/public'));
app.use(bodyParser.urlencoded({extended: true}));

const menu = [
    {
        name: 'Nyitó oldal',
        url: '/'
    },
];

app.get('/', (req,res)=>{
    let data ={
        title: 'Nyitó oldal',
        menu: menu,
        url: req.url
    };
    res.render('pages/index',data);
});

app.listen(port,()=>{ 
    console.log(`App listening at http://localhost:${port}`);
 });

