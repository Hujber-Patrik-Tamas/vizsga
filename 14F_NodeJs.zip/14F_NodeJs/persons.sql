DROP TABLE IF EXISTS `persons`;

CREATE TABLE `persons` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `country` varchar(100) default NULL,
  PRIMARY KEY (`id`)
) AUTO_INCREMENT=1;

INSERT INTO `persons` (`id`,`name`,`email`,`country`)
VALUES
  (1,"Guinevere Velazquez","guineverevelazquez7316@protonmail.edu","Vietnam"),
  (2,"Hector Perkins","hectorperkins6423@google.edu","Vietnam"),
  (3,"Carla Francis","carlafrancis@yahoo.couk","Mexico"),
  (4,"Chester Haynes","chesterhaynes@hotmail.couk","Colombia"),
  (5,"Tanek Mccormick","tanekmccormick@icloud.com","Ireland"),
  (6,"Velma Hardy","velmahardy8246@icloud.org","Vietnam"),
  (7,"Pascale Malone","pascalemalone2818@outlook.couk","South Korea"),
  (8,"Matthew O'connor","matthewoconnor8912@protonmail.ca","United States"),
  (9,"Stacy Howe","stacyhowe374@hotmail.net","Nigeria"),
  (10,"Freya Sloan","freyasloan6876@hotmail.edu","Poland");
INSERT INTO `persons` (`id`,`name`,`email`,`country`)
VALUES
  (11,"Keaton Kramer","keatonkramer2006@google.org","Austria"),
  (12,"Yuri Freeman","yurifreeman6612@yahoo.net","Italy"),
  (13,"Naida Padilla","naidapadilla4596@icloud.edu","Italy"),
  (14,"Armando Chapman","armandochapman@hotmail.org","Vietnam"),
  (15,"Herman Howe","hermanhowe@icloud.edu","China"),
  (16,"Cyrus Fox","cyrusfox9657@hotmail.net","Australia"),
  (17,"Amity Maddox","amitymaddox@yahoo.edu","Colombia"),
  (18,"Oren Shaffer","orenshaffer2869@yahoo.edu","Russian Federation"),
  (19,"Jillian Mclaughlin","jillianmclaughlin@hotmail.net","United Kingdom"),
  (20,"Helen Kirkland","helenkirkland7755@icloud.couk","Sweden");
INSERT INTO `persons` (`id`,`name`,`email`,`country`)
VALUES
  (21,"Salvador Dillon","salvadordillon521@yahoo.couk","China"),
  (22,"Neil Cotton","neilcotton3550@icloud.net","Colombia"),
  (23,"Calista Collier","calistacollier@protonmail.org","Italy"),
  (24,"Elliott Baker","elliottbaker9055@google.ca","United Kingdom"),
  (25,"Fatima Schroeder","fatimaschroeder@yahoo.net","Peru"),
  (26,"Kelsey Chan","kelseychan1613@hotmail.couk","United Kingdom"),
  (27,"Zorita Branch","zoritabranch7976@outlook.org","Spain"),
  (28,"Steel Fields","steelfields@aol.ca","Australia"),
  (29,"Lynn Lancaster","lynnlancaster9641@outlook.couk","Belgium"),
  (30,"Axel Foley","axelfoley1768@aol.com","Indonesia");
INSERT INTO `persons` (`id`,`name`,`email`,`country`)
VALUES
  (31,"Indira Bradley","indirabradley@outlook.edu","Netherlands"),
  (32,"Hammett Davidson","hammettdavidson564@outlook.edu","Vietnam"),
  (33,"Eaton Oneil","eatononeil@yahoo.ca","Spain"),
  (34,"Georgia Owens","georgiaowens@google.org","Colombia"),
  (35,"Graham Caldwell","grahamcaldwell6673@yahoo.org","Netherlands"),
  (36,"Cairo Petersen","cairopetersen8280@google.couk","Indonesia"),
  (37,"Clayton Barlow","claytonbarlow@hotmail.couk","Nigeria"),
  (38,"Summer Allen","summerallen@aol.org","Germany"),
  (39,"Regan Brooks","reganbrooks@outlook.net","Poland"),
  (40,"Jonah Workman","jonahworkman8551@protonmail.couk","Spain");
INSERT INTO `persons` (`id`,`name`,`email`,`country`)
VALUES
  (41,"Graham Stone","grahamstone@hotmail.net","Australia"),
  (42,"Jaime Parrish","jaimeparrish1354@yahoo.edu","Germany"),
  (43,"Hilel Smith","hilelsmith2838@yahoo.net","Italy"),
  (44,"Janna Velez","jannavelez@hotmail.ca","Netherlands"),
  (45,"Kaye George","kayegeorge3690@protonmail.org","Russian Federation"),
  (46,"Yolanda Boyle","yolandaboyle5621@icloud.ca","Canada"),
  (47,"Diana Wade","dianawade945@outlook.couk","Mexico"),
  (48,"Aimee Mcclure","aimeemcclure@yahoo.couk","Pakistan"),
  (49,"Caleb Brewer","calebbrewer@outlook.org","Peru"),
  (50,"Malcolm Banks","malcolmbanks@aol.com","Nigeria");
INSERT INTO `persons` (`id`,`name`,`email`,`country`)
VALUES
  (51,"Dylan Lester","dylanlester@google.net","Indonesia"),
  (52,"Justina Langley","justinalangley9448@icloud.edu","Brazil"),
  (53,"Dominique Stewart","dominiquestewart@yahoo.com","Spain"),
  (54,"Gage Gardner","gagegardner@protonmail.ca","Nigeria"),
  (55,"Ralph Quinn","ralphquinn@outlook.net","Netherlands"),
  (56,"Benedict Dodson","benedictdodson@icloud.org","New Zealand"),
  (57,"Iola Franklin","iolafranklin920@yahoo.org","China"),
  (58,"Nathaniel Frost","nathanielfrost@protonmail.com","India"),
  (59,"Orson Larson","orsonlarson3198@google.ca","Germany"),
  (60,"Aaron Bryant","aaronbryant@yahoo.org","Vietnam");
INSERT INTO `persons` (`id`,`name`,`email`,`country`)
VALUES
  (61,"Linda Wood","lindawood2104@google.net","Australia"),
  (62,"Joseph Montoya","josephmontoya@google.com","New Zealand"),
  (63,"Theodore Lindsay","theodorelindsay@google.couk","Netherlands"),
  (64,"Quinlan Fitzgerald","quinlanfitzgerald@protonmail.ca","Nigeria"),
  (65,"Carla Young","carlayoung@aol.org","Spain"),
  (66,"Penelope David","penelopedavid@icloud.com","Brazil"),
  (67,"Colin Mejia","colinmejia@protonmail.ca","Colombia"),
  (68,"Cairo Richardson","cairorichardson9068@yahoo.org","China"),
  (69,"Sebastian Kelly","sebastiankelly@outlook.com","Vietnam"),
  (70,"Karina Baker","karinabaker@outlook.com","Ireland");
INSERT INTO `persons` (`id`,`name`,`email`,`country`)
VALUES
  (71,"Idona Nguyen","idonanguyen@google.edu","Poland"),
  (72,"Blythe Woodward","blythewoodward@yahoo.edu","South Korea"),
  (73,"Madeson Tyler","madesontyler@yahoo.net","Belgium"),
  (74,"Bree Barrera","breebarrera1710@hotmail.edu","Chile"),
  (75,"Aidan Chaney","aidanchaney8307@hotmail.ca","Sweden"),
  (76,"Mannix Spears","mannixspears3790@outlook.com","Nigeria"),
  (77,"Lucian Ellison","lucianellison2464@yahoo.com","Vietnam"),
  (78,"Michael Morton","michaelmorton7007@aol.net","United States"),
  (79,"Phyllis Blackwell","phyllisblackwell836@protonmail.ca","Brazil"),
  (80,"Halee Wyatt","haleewyatt@google.com","Austria");
INSERT INTO `persons` (`id`,`name`,`email`,`country`)
VALUES
  (81,"Jeremy Arnold","jeremyarnold7611@aol.ca","Indonesia"),
  (82,"Aaron Colon","aaroncolon5598@aol.edu","Germany"),
  (83,"Emma Cummings","emmacummings9318@hotmail.net","Russian Federation"),
  (84,"Keely Mathews","keelymathews8106@yahoo.org","Germany"),
  (85,"Willa Farmer","willafarmer@outlook.org","Mexico"),
  (86,"Noelle Zamora","noellezamora@protonmail.com","Chile"),
  (87,"Caryn Schultz","carynschultz@outlook.edu","Australia"),
  (88,"Rhonda Leon","rhondaleon@aol.couk","Poland"),
  (89,"Simon May","simonmay3099@google.ca","Nigeria"),
  (90,"Harding York","hardingyork3513@yahoo.net","Chile");
INSERT INTO `persons` (`id`,`name`,`email`,`country`)
VALUES
  (91,"Dara Pope","darapope@outlook.ca","Nigeria"),
  (92,"Yardley Mercado","yardleymercado1829@outlook.com","Poland"),
  (93,"Beck Calhoun","beckcalhoun7978@aol.couk","Sweden"),
  (94,"Lee Cummings","leecummings@protonmail.ca","Germany"),
  (95,"Dominique Mcintosh","dominiquemcintosh@outlook.org","Spain"),
  (96,"Demetria Conrad","demetriaconrad245@aol.com","Netherlands"),
  (97,"Justin Kirkland","justinkirkland@outlook.couk","Sweden"),
  (98,"Olympia Mccoy","olympiamccoy5770@aol.edu","Spain"),
  (99,"Germane Palmer","germanepalmer4696@aol.net","Costa Rica"),
  (100,"Neil Sheppard","neilsheppard7356@yahoo.ca","Brazil");
