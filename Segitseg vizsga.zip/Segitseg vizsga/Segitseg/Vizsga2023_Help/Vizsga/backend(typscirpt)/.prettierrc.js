module.exports = {
    semi: true,
    trailingComma: "all",
    printWidth: 160,
    tabWidth: 4,
    endOfLine: "auto",
    arrowParens: "avoid",
};
