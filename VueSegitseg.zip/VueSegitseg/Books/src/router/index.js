import { createRouter, createWebHistory } from "vue-router";
import HomeView from "../views/HomeView.vue";
import BookListView from "../views/BookListView.vue";
import BookTableView from "../views/BookTableView.vue";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      name: "home",
      component: HomeView,
    },
    {
      path: "/booklist",
      name: "BookListView",
      component: BookListView,
    },
    {
      path: "/booktable",
      name: "BookTableView",
      component: BookTableView,
    },
  ],
});

export default router;
