<template>
    <div class="container">
        <div class="row">
            <div v-for="book in booklist" class="col col-md-4">
                <book-item :book="book"></book-item>
            </div>
            
        </div>
    </div>
</template>

<script setup>
import BookItem from '../components/BookItem.vue'
import BookData from '../bookdata'
const booklist = BookData

</script>