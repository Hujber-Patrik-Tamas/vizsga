<template>
    <table>
        <tr>
            <td>Cím</td>
            <td>Szerző</td>
            <td>Leírás</td>
            <td>Kép url</td>
        </tr>
        <tr v-for="book in booklist">
            <td>{{ book.title }}</td>
            <td>{{ book.author }}</td>
            <td>{{ book.description }}</td>
            <td> <img :src="book.img_url" alt="">
            </td>
        </tr>
    </table>
</template>

<script setup>
import BookData from '../bookdata'
const booklist = BookData

</script>