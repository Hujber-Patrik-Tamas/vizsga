<script setup>
import {  ref } from 'vue'

const sorsolt = ref([])
const tippek = ref([0, 0, 0, 0, 0])

</script>

<template>
 <div class="container">
    <p class="display-1 text-center">Lottó</p>
    <p>Tippem</p>
    <ul>
        <li v-for="tipp in tippek">
            <input type="number" />
        </li>
    </ul>
    <button>Megnéz</button>
    <p>Lottó számok: {{  }}</p>
    <p>Találat: {{  }}</p>
 </div>
</template>
