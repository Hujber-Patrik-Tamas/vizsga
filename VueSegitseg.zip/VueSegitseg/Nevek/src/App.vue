<script setup>
import InputForm from "./components/InputForm.vue";
import NamesList from "./components/NamesList.vue";
</script>

<template>
  <input-form></input-form>
  <NamesList title="Név lista" />
</template>

<style scoped></style>
