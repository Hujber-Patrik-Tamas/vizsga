<template>
  <div class="container">
    <h2>Új név</h2>
    <label class="form-label" for="nev">Név:</label>
    <input class="form-control mb-3" type="text" id="nev" />
    <button class="btn btn-primary">Mentés</button>
  </div>
</template>
