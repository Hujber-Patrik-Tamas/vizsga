<script setup>
const props = defineProps(["title"]);
</script>
<template>
  <div class="container">
    <h2>{{ title }}</h2>
  </div>
</template>
