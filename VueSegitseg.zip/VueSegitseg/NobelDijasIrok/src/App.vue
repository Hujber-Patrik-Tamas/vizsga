<script setup>
import { RouterView } from 'vue-router';
</script>

<template>
<div class="container">
 <router-view/>
</div>
</template>

<style scoped>

</style>
