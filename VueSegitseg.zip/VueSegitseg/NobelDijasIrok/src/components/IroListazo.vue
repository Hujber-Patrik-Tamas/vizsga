<template>
  <div>
    <h2>Nobel-díjas írók</h2>
    <ul>
      <li>Camus</li>
      <li>Szolzsenyicin</li>
    </ul>
  </div>
</template>
