<template>
    <div>
        <h2>Földrészek</h2>
        <select name="" id="" v-model="aktKontinens">
            <option v-for="kontinens in Kontinensek" :key="kontinens" :value="kontinens">{{ kontinens }}</option>
        </select>
    </div>
</template>

<script setup>
import {storeToRefs} from 'pinia'
import { useNobeldijasIrok } from '../stores'

const { Kontinensek, aktKontinens } = storeToRefs(useNobeldijasIrok())

</script>