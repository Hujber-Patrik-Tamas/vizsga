<template>
    <div>
        <h2>Országok</h2>
        <select name="" id="">
            <option v-for="orszag in KontinensOrszagai" value="orszag.azon">{{ orszag.orszag }}</option>
        </select>
    </div>
</template>

<script setup>
import {storeToRefs} from 'pinia'
import { useNobeldijasIrok } from '../stores'

const { KontinensOrszagai } = storeToRefs(useNobeldijasIrok())
console.log(KontinensOrszagai);
</script>