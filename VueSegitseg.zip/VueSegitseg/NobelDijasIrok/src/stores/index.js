import { defineStore } from "pinia";
import Axios from "axios";
Axios.defaults.baseURL = "http://localhost:3000";

export const useNobeldijasIrok = defineStore({
  id: "NobeldijasIrok",
  state: () => ({
    orszagok: [],
    irok: [],
    aktKontinens: null
  }),
  getters: {
    Kontinensek(state) {
      const kontinensek = state.orszagok.map(o => o.kontinens)
      return new Set(kontinensek)
    },
    KontinensOrszagai(state) {
      const aktOrszagok = state.orszagok.filter(o => o.kontinens === state.aktKontinens)
      return aktOrszagok
    }
  },
  actions: {
    getOrszagok() {
      return Axios.get("/orszag")
        .then((resp) => {
          //console.log(resp.data);
          this.orszagok = resp.data;
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getIrok() {
      return Axios.get("/iro")
        .then((resp) => {
          //console.log(resp.data);
          this.irok = resp.data;
        })
        .catch((err) => {
          console.log(err);
        });
    },
  },
});
