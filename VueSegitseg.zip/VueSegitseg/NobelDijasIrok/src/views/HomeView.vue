<script setup>
import KontinensLista from "../components/KontinensLista.vue";
import OrszagLista from "../components/OrszagLista.vue";
import IroListazo from "../components/IroListazo.vue";

import { onBeforeMount } from "vue";
import { useNobeldijasIrok } from "../stores";

onBeforeMount(() => {
  const { getOrszagok, getIrok } = useNobeldijasIrok();
  getOrszagok();
  getIrok();
});
</script>

<template>
  <div class="row">
    <div class="col-md-4">
      <kontinens-lista></kontinens-lista>
      <orszag-lista></orszag-lista>
    </div>
    <div class="col-md-8">
      <iro-listazo></iro-listazo>
    </div>
  </div>
</template>
