const mobilGyartok = [
  {
    "_id": 1,
    "név": "Apple",
    "alapítva": 1976,
    "elnök": "Tim Cook"
  },
  {
    "_id": 2,
    "név": "Samsung",
    "alapítva": 1938,
    "elnök": "Kim Ki Nam"
  },
  {
    "_id": 3,
    "név": "Nokia",
    "alapítva": 1865,
    "elnök": "Pekka Lundmark"
  },
  {
    "_id": 4,
    "név": "Xiaomi",
    "alapítva": 2010,
    "elnök": "Lej Csün"
  },
  {
    "_id": 5,
    "név": "Oppo",
    "alapítva": 2004,
    "elnök": "Tony Chen"
  },
  {
    "_id": 6,
    "név": "Motorola",
    "alapítva": 2011,
    "elnök": "Greg Brown"
  },
  {
    "_id": 7,
    "név": "Huawei",
    "alapítva": 1987,
    "elnök": "Zsen Cseng-fej"
  }
]

export default mobilGyartok