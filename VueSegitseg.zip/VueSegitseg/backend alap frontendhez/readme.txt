Ez a minta könyveket és könyvkiadókat tartalmaz.
A szükséges adatbázist létre kell hozni hozzá a localhost-on a mellékelt 
parancsfájl (mongo.bat) futtatásával

