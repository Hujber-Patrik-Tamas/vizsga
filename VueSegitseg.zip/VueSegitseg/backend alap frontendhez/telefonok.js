const telefonok =[
  {
    "név": "iPhone 14",
    "ár": 349990,
    "szín": "piros",
    "gyártó": 1 
  },
  {
    "név": "iPad 9 tablet",
    "ár": 159990,
    "szín": "ezüst",
    "gyártó": 1 
  },
  {
    "név": "Apple Watch SE2 GPS",
    "ár": 124990,
    "szín": "fekete",
    "gyártó": 1 
  },
  {
    "név": "Samsung Galaxy S23 Ultra 5G",
    "ár": 689990,
    "szín": "fantomfekete",
    "gyártó": 2 
  },
  {
    "név": "Samsung Galaxy A33 5G",
    "ár": 124990,
    "szín": "fekete",
    "gyártó": 2 
  },
  {
    "név": "Nokia 105 (2019) feltöltőkártyás",
    "ár": 5490,
    "szín": "fekete",
    "gyártó": 3 
  },
  {
    "név": "Xiaomi F490, DVB4303GL, 4G LTE",
    "ár": 22389,
    "szín": "kék",
    "gyártó": 4 
  },
  {
    "név": "OPPO Find X5 Pro",
    "ár": 557590,
    "szín": "glaze black",
    "gyártó": 5 
  },
  {
    "név": "Oppo Reno 6 Pro",
    "ár": 298975,
    "szín": "lunar grey",
    "gyártó": 5 
  },
  {
    "név": "Motorola Moto Razr 2022",
    "ár": 529990,
    "szín": "fekete",
    "gyártó": 6 
  },
  {
    "név": "Motorola Edge 30 Pro 5G",
    "ár": 465842,
    "szín": "stardust white",
    "gyártó": 6 
  },
  {
    "név": "Huawei Mate 50 Pro",
    "ár": 561690,
    "szín": "ezüst",
    "gyártó": 7 
  }
]

export default telefonok