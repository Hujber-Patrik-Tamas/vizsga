<template>
  <div class="about">
    <h1>About</h1>
  </div>
</template>