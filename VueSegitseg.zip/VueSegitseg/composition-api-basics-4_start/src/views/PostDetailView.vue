<template>
  <div class="post-detail">
    <h1>Post részletei</h1>
    <p>A képernyőn lévő hozzászólás ID-je: {{ $route.params.id }}</p>
    <div>
      <button @click="showPostId">Mutasd a hozzászólás ID-jét!</button>
    </div>
    <div>
      <button @click="goHomeIn3Seconds">Menj a kezdőlapra 3mp múlva!</button>
    </div>
    <div>
      <button @click="goToFirstPost">Menj az első hozzászóláshoz!</button>
    </div>
    <p><RouterLink to="/posts">&lt; Back</RouterLink></p>
  </div>
</template>

<script setup>
import { useRoute, useRouter } from "vue-router";

const route = useRoute();
const router = useRouter();

const showPostId = () => {
  alert(`The ID of this post is: ${route.params.id}`);
};

const goHomeIn3Seconds = () => {
  setTimeout(() => {
    router.push({ name: "home" });
  }, 3000);
};

const goToFirstPost = () => {
  router.push({
    name: "postDetail",
    params: {
      id: "id1",
    },
  });
};
</script>
