<template>
      <teleport to="body">
        <div v-if="modelValue" class="modal">
          <h1> {{ title }} </h1>
          <slot></slot>
          <button @click="$emit('update:modelValue', false)">Hide modal</button>
        </div>
      </teleport>
  </template>
  
  <!-- const props = defineProps(['title']) -->
  <script setup>
    const props = defineProps({
      modelValue: {
        type: Boolean,
        default: false
      },
      title: {
        type: String,
        default: 'No title specified'
      }
    })

    const emit = defineEmits(['update:modelValue'])

  </script>
  
  <style>
  .modal {
    background: beige;
    padding: 10px;
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
  }
  </style>
  