<template>
  <div class="modals">
    <h1>Modals</h1>
    <button @click="showModal = true">Show modal</button>
    <Modal v-model="showModal" title="My modal title (via prop)">
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam pariatur
        debitis laborum, facere ratione officia possimus voluptatum delectus
        nisi maiores veniam temporibus rerum animi dolore eius adipisci
        perspiciatis eum dolor.
      </p>
    </Modal>
  </div>
</template>

<script setup>
import { ref } from "vue";
import Modal from "@/components/Modal.vue";
const showModal = ref(false);
</script>
