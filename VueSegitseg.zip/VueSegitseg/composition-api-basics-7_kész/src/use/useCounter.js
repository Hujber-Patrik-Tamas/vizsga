import { reactive, computed, watch, onMounted } from 'vue'

const counterData = reactive({
  count: 0,
  title: 'My Counter',
})

export function useCounter() {

  watch(
    () => counterData.count,
    (newCount) => {
      if (newCount === 20) {
        alert('Elérted a 20-at!!')
      }
    },
  )

  const oddOrEven = computed(() => {
    if (counterData.count % 2 === 0) return 'even'
    return 'odd'
  })

  const increaseCounter = (amount, e) => {
    counterData.count += amount
  }

  const decreaseCounter = (amount) => {
    counterData.count -= amount
  }

  onMounted(() => {
    console.log('Csinálunk valamit a számlálóval.')
  })

  return {
    counterData,
    oddOrEven,
    increaseCounter,
    decreaseCounter
  }
}
