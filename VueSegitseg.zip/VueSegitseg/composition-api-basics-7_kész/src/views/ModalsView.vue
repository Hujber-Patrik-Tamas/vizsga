<template>
  <div class="modals">
    <h1>Modals</h1>
    <div>
      <label for="sotet">
        Show dark modals?
        <input v-model="showDarkModals" type="checkbox" id="sotet">
      </label>
    </div>
    <pre>{{ showDarkModals }}</pre>
    <button @click="showModal = true">Show modal</button>
    <component 
      :is='showDarkModals ? ModalDark : Modal' 
      v-model="showModal" 
      title="My modal title (via prop)"
      >
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam pariatur
        debitis laborum, facere ratione officia possimus voluptatum delectus
        nisi maiores veniam temporibus rerum animi dolore eius adipisci
        perspiciatis eum dolor.
      </p>
    </component>
  </div>
</template>

<script setup>
import { ref } from "vue";
import Modal from "@/components/Modal.vue";
import ModalDark from "@/components/ModalDark.vue";

const showDarkModals = ref(false)
const showModal = ref(false);
</script>
