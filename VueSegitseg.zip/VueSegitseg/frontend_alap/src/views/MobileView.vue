<template>
    <div>
        Mobilok
    </div>
</template>