<template>
  <div>
    <h1>Könyv választása</h1>
    <label for="books">Válassz egy könyvet:</label>

    <select v-model="kivalasztott" @change="kivalaszt" name="books" id="books">
      <option v-for="szerzo in szerzőLista">{{ szerzo }}</option>
    </select>

    <ul>
      <li v-for="kkonyv in címLista">{{ kkonyv.title }}</li>
    </ul>
  </div>
</template>
<script setup>
import books from "../bookdata";
import { ref } from "vue";

const kivalasztott = ref();
const címLista = ref([]);
const szerzőLista = ref([]);

for (let index = 0; index < books.length; index++) {
  if (!szerzőLista.value.includes(books[index].author)) {
    szerzőLista.value.push(books[index].author);
  }
}
console.log(szerzőLista.value);
const kivalaszt = () => {
  // console.log(kivalasztott.value);
  címLista.value = books.filter((b) => b.author === kivalasztott.value);
  console.log(címLista);
};
</script>
