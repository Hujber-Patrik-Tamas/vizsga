<template>
  <div>
    <h1>Pizza rendeléseket listázó alkalmazás</h1>
  </div>
</template>