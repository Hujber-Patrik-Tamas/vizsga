<script setup>
import DataService from "../services/dataservice";
import { ref } from "vue";

const pizzak = ref([]);
const rendelesek = ref([]);
const valasztas = ref();
const jorendelesek = ref([])

DataService.getAllPizzak()
  .then((resp) => {
    pizzak.value = resp;
    console.log(pizzak.value);
  })
  .catch((err) => {
    console.log(err);
  });

DataService.getAllRendelesek()
  .then((resp) => {
    rendelesek.value = resp;
    console.log(rendelesek.value);
  })
  .catch((err) => {
    console.log(err);
  });

  const valaszto = () => {
    jorendelesek.value = []
    jorendelesek.value = rendelesek.value.filter(r => r.pizza.name === valasztas.value)
    console.log(jorendelesek.value);
  }

</script>

<template>
  <select v-model="valasztas" @change="valaszto">
    <option v-for="pizza in pizzak">{{ pizza.name }}</option>
  </select>
  <ul>
    <li v-for="jorendeles in jorendelesek">{{ jorendeles.name }}</li>
  </ul>
  
</template>
