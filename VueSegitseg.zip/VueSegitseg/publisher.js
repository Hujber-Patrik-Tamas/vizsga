const publishers=[
	{
    név: "Akadémiai Kiadó",
    alapítva: 1828,
    székhely: "Budapest, Budafoki út 187–189."
  },
  {
    név: "Cartographia",
    alapítva: 1954,
    székhely: "Budapest, Nyugati tér 1."
  },
  {
    név: "Európa Könyvkiadó",
    alapítva: 1946,
    székhely: "Budapest"
  },
  {
    név: "Gondolat Kiadó",
    alapítva: 1957,
    székhely: "Budapest"
  },
  {
    név: "Libri Kiadó",
    alapítva: 2011,
    székhely: "Budapest"
  },
  {
    név: "Magvető Könyvkiadó",
    alapítva: 1955,
    székhely: "Budapest"
  },
]

export default publishers;