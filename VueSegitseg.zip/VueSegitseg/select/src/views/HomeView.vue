<script setup>
import publishers from '../publisher'
import { ref } from 'vue'

const kiadok = ref([])
const választás = ref("")
kiadok.value = publishers
console.log(kiadok.value[0].név);

const valaszto = () => {
    console.log(választás.value);
}
</script>

<template>
    <label for="publishers">Choose a publisher:</label>

    <select @change="valaszto" name="publishers" id="publishers" v-model="választás">
        <!-- <option value="default">Válassz!</option> -->
        <option v-for="kiado in kiadok">{{ kiado.név }}</option>
    </select>
    <h1>A választásod: {{ választás }}</h1>
</template>
