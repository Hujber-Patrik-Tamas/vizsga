﻿using CarOfTheYear2023.EF;
using CarOfTheYear2023.Swagger;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Swashbuckle.AspNetCore.Annotations;
using Swashbuckle.AspNetCore.Filters;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.Reflection;

namespace CarOfTheYear2023.Controllers
{
    [ApiController]
    [Route("api")]
    public class ApiController : ControllerBase
    {
        private readonly ApplicationContext dbContext;
        private string baseURL = "";
        public ApiController(ApplicationContext dbContext, IConfiguration configuration)
        {
            this.dbContext = dbContext;
            baseURL = configuration.GetValue<string>("BaseURL");
        }

        [HttpGet("manufacturers", Name = "ListManufacturers")]
        public IActionResult Manufacturers()
        {
            return Ok (dbContext.Set<ManufacturerModel>().ToList().OrderBy(m => m.Name));
        }
        
        [HttpGet("cars/{manufacturerId?}", Name = "ListCars")]
        [SwaggerOperationFilter(typeof(MyOperationFilter))]
        public IActionResult Cars([FromRoute] string? manufacturerId)
        {
            return Ok
            (
                dbContext.Set<CarModel>()
                         .Include(c => c.Manufacturer)
                         .Where(c => string.IsNullOrEmpty(manufacturerId) || c.ManufacturerId.ToString() == manufacturerId)
                         .Select(c => new
                         {
                             c.Id,
                             c.ManufacturerId,
                             ManufacturerName = c.Manufacturer.Name,
                             c.Model,
                             c.Description,
                             PictureUrl = $"{baseURL}/picture/pict{c.Id}.jpg"
                         })
                         .ToList()
            );
        }
        
        [HttpPatch("car/{id}")]
        [SwaggerRequestExample(typeof(CarModel), typeof(CarModel))]
        public IActionResult Patch([FromRoute] int id, [FromBody] string description)
        {
            try
            {
                var originalModel = dbContext.Set<CarModel>().Include(c => c.Manufacturer).SingleOrDefault(v => v.Id == id);
                if (originalModel == null)
                    return NotFound(new { Message = $"There is no car with id {id}!" });

                if (description.Length < 50 )
                    return BadRequest(new { Message = "The description must be at least 50 characters!" });

                if (description.Length > 7000)
                    return BadRequest(new { Message = "The description cannot be longer than 7000 characters!" });

                originalModel.Description = description;
                dbContext.Entry(originalModel).State = EntityState.Modified;
                dbContext.SaveChanges();

                return Ok(new
                {
                    originalModel.Id,
                    originalModel.ManufacturerId,
                    ManufacturerName = originalModel.Manufacturer.Name,
                    originalModel.Model,
                    originalModel.Description,
                    PictureUrl = $"{baseURL}/picture/pict{originalModel.Id}.jpg"
                });
            }
            catch (MissingFieldException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(new
                {
                    Message = "Missing data.",
                    DebugMessage = ex.Message
                });
            }
        }

        [HttpPost("vote")]
        [SwaggerRequestExample(typeof(VoteModel), typeof(VoteModel))]
        public IActionResult Vote([FromBody] dynamic voteRequest)
        {
            try
            {
                var model = (VoteModel)System.Text.Json.JsonSerializer
                           .Deserialize<VoteModel>(
                                voteRequest.ToString(),
                                new System.Text.Json.JsonSerializerOptions()
                                {
                                    PropertyNameCaseInsensitive = true,
                                    NumberHandling = System.Text.Json.Serialization.JsonNumberHandling.AllowReadingFromString
                                });

                if (model.CarId == 0)
                    return BadRequest(new { Message = "Missing: carId" });
                if (!dbContext.Set<CarModel>().Any(c => c.Id == model.CarId))
                    return BadRequest(new { Message = $"There is no car with id {model.CarId}" });
                if (string.IsNullOrEmpty(model.Email))
                    return BadRequest(new { Message = "Missing: e-mail address" });
                string email = model.Email.ToLower();
                if (dbContext.Set<VoteModel>().Any(v => v.Email.ToLower() == email))
                    return BadRequest(new { Message = "You have already voted with this email address." });

                dbContext.Set<VoteModel>().Add(model);
                dbContext.SaveChanges();
                return Ok(new
                {
                    Message = "Successful vote"
                });
            }
            catch (MissingFieldException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(new
                {
                    Message = "Missing data",
                    DebugMessage = ex.Message
                });
            }
        }

        [HttpGet("votes")]
        public IActionResult Votes()
        {
            return Ok
            (
                dbContext.Set<CarModel>().Include(c => c.Votes).Select(c => new
                {
                    c.Model,
                    Votes = c.Votes.Count()
                })
                .OrderBy(v => v.Model)
            );
        }

        [HttpGet("/picture/{fileName}")]
        [ApiExplorerSettings(IgnoreApi = true)]
        public IActionResult GetImage([FromRoute] string fileName)
        {
            try
            {
                byte[] ba = Convert.FromBase64String(dbContext.Set<CarModel>().Single(c => $"pict{c.Id}.jpg" == fileName).Picture);
                return File(ba, "image/jpeg");
            }
            catch
            {
                return NotFound("Image not found");
            }
        }
    }
}