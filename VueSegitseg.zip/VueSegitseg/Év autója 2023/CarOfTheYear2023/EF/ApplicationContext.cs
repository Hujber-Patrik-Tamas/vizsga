﻿using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace CarOfTheYear2023.EF
{
    public class ApplicationContext: DbContext
    {
        public DbSet<VoteModel> Votes { get; set; }

        public ApplicationContext(DbContextOptions options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<VoteModel>().HasIndex(v => v.Email).IsUnique();
            modelBuilder.Entity<ManufacturerModel>().HasIndex(m => m.Name).IsUnique();
            modelBuilder.Entity<CarModel>().HasIndex(m => m.Model).IsUnique();

            modelBuilder.Entity<ManufacturerModel>().HasData(JsonConvert.DeserializeObject<ManufacturerModel[]>(File.ReadAllText("manufacturer.json")));
            modelBuilder.Entity<CarModel>().HasData(JsonConvert.DeserializeObject<CarModel[]>(File.ReadAllText("cars.json")));
        }
    }
}
