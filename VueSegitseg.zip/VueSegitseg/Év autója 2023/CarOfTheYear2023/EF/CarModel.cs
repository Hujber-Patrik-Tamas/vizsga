﻿namespace CarOfTheYear2023.EF
{
    public class CarModel
    {
        public int Id { get; set; }
        public int ManufacturerId { get; set; }
        public ManufacturerModel Manufacturer { get; set; }
        public string Model { get; set; }
        public string Picture { get; set; }
        public string PictureUrl { get; set; }
        public string Description { get; set; }

        public virtual IEnumerable<VoteModel> Votes { get; set; }
    }
}
