﻿namespace CarOfTheYear2023.EF
{
    public class VoteModel
    {
        public int Id { get; set; }
        public CarModel Car { get; set; }
        public int CarId { get; set; }
        public string Email { get; set; }
        public string Comment { get; set; }
    }
}
