using CarOfTheYear2023.EF;
using CarOfTheYear2023.Swagger;
using Microsoft.EntityFrameworkCore;
using Swashbuckle.AspNetCore.SwaggerGen;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Configuration.SetBasePath(Directory.GetCurrentDirectory())
                     .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                     .AddEnvironmentVariables();

builder.Services.AddControllers();
builder.Services.AddDbContext<ApplicationContext>(o => {
    //o.UseSqlite("Data Source=./caroftheyear");
    o.UseInMemoryDatabase("caroftheyear");
});

builder.Services.AddCors(option =>
{
    option.AddPolicy("EnableCORS", builder =>
    {
        builder.SetIsOriginAllowed(origin => true)
            .AllowAnyMethod()
            .AllowAnyHeader()
            .AllowCredentials()
            .Build();
    });
});

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.OperationFilter<MyOperationFilter>();
    c.SchemaFilter<MySchemaFilter>();
});

var app = builder.Build();

var routePath = app.Configuration.GetValue<string>("virtualdirectory");

app.UseCors("EnableCORS");
app.UseSwagger(c =>
{
    c.RouteTemplate = "docs/{documentName}/swagger.json";
    c.PreSerializeFilters.Add((swagger, httpReq) =>
    {
        var oldPaths = swagger.Paths.ToDictionary(entry => entry.Key, entry => entry.Value);
        foreach (var path in oldPaths)
        {
            swagger.Paths.Remove(path.Key);
            swagger.Paths.Add(path.Key.Replace("api", $"{routePath}api"), path.Value);
        }
    });
});
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("v1/swagger.json", "Car of the year 2023 API");
    c.RoutePrefix = "docs";

});

using (var scope = app.Services.CreateScope())
using (var context = scope.ServiceProvider.GetService<ApplicationContext>())
    context?.Database.EnsureCreated();

app.UseAuthorization();

app.MapControllers();

app.Run();