﻿using CarOfTheYear2023.Swagger;
using Microsoft.OpenApi.Any;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.Text.Json.Serialization;

public class MySchemaFilter : ISchemaFilter
{
    public void Apply(OpenApiSchema schema, SchemaFilterContext context)
    {
        if (context.ParameterInfo == null)
            return;
        if (context.ParameterInfo.Name == "voteRequest")
        {
            schema.Example = new OpenApiObject()
            {
                ["carId"] = new OpenApiInteger(new Random().Next(1, 27)),
                ["email"] = new OpenApiString(RandomEmailGenerator.GenerateRandomEmail()),
                ["comment"] = new OpenApiString("Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore ex laborum possimus numquam corporis, nulla error impedit illo iusto quibusdam animi eius, nemo dicta velit sint consectetur magnam. Provident, ipsum.")
            };
        }
        if (context.ParameterInfo.Name == "description")
        {
            schema.Example = new OpenApiString("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Semper viverra nam libero justo laoreet. Odio ut enim blandit volutpat maecenas. Tristique senectus et netus et malesuada fames ac turpis egestas. Tempor commodo ullamcorper a lacus vestibulum sed arcu. Pretium nibh ipsum consequat nisl. A lacus vestibulum sed arcu non odio euismod lacinia at. Maecenas pharetra convallis posuere morbi leo urna. Non arcu risus quis varius quam quisque id diam vel. Enim diam vulputate ut pharetra sit amet.\nOrnare quam viverra orci sagittis eu volutpat odio facilisis mauris. Aliquam nulla facilisi cras fermentum. Ut lectus arcu bibendum at varius. Vitae congue eu consequat ac felis donec et. Maecenas volutpat blandit aliquam etiam erat velit scelerisque in dictum. Vehicula ipsum a arcu cursus vitae congue mauris rhoncus aenean. Viverra aliquet eget sit amet tellus cras. Proin sed libero enim sed faucibus turpis. Nullam vehicula ipsum a arcu cursus vitae. Risus pretium quam vulputate dignissim suspendisse in est ante in. Consequat nisl vel pretium lectus quam id leo in vitae. Venenatis tellus in metus vulputate eu scelerisque felis imperdiet proin. Vestibulum lectus mauris ultrices eros in. Posuere urna nec tincidunt praesent semper feugiat nibh sed.\nMolestie nunc non blandit massa. Maecenas accumsan lacus vel facilisis volutpat. Nisi scelerisque eu ultrices vitae auctor eu augue ut. Odio pellentesque diam volutpat commodo sed egestas egestas fringilla phasellus. Id volutpat lacus laoreet non curabitur gravida arcu. Turpis nunc eget lorem dolor sed viverra ipsum nunc aliquet. Nullam non nisi est sit amet facilisis magna etiam. Varius sit amet mattis vulputate enim nulla aliquet porttitor lacus. In aliquam sem fringilla ut morbi tincidunt augue interdum velit. Vel pharetra vel turpis nunc. Adipiscing at in tellus integer feugiat scelerisque varius morbi enim. Enim sed faucibus turpis in eu mi bibendum neque. Semper viverra nam libero justo laoreet sit amet. Rutrum quisque non tellus orci ac auctor augue. At tempor commodo ullamcorper a. Viverra nibh cras pulvinar mattis nunc sed blandit libero. Massa enim nec dui nunc. Facilisi cras fermentum odio eu feugiat pretium nibh. Tortor posuere ac ut consequat semper.");
        }
    }
}
