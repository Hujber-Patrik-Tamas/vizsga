﻿namespace CarOfTheYear2023.Swagger
{
    public static class RandomEmailGenerator
    {
        private static string[] lastnames = { "Márton", "Berki", "Sárközi", "Kerekes", "Mezei", "Borbély", "Barta", "Faragó", "Péter", "Csonka", "Balla", "Pataki", "Nemes", "Soós", "Tamás", "Novák", "Barna", "Hegedüs", "Orbán", "Major", "Virág", "Dudás", "Bakos", "Pásztor", "Gáspár", "Kozma", "Székely", "Máté", "Halász", "Hajdu", "Szücs", "Vörös", "Bognár", "Bodnár", "Lengyel", "Jónás", "Fábián", "Szőke", "Vass", "Pál", "Illés", "Bálint", "Pap", "Hegedűs", "Deák", "Vincze", "Veres", "Budai", "Fülöp", "Somogyi", "Antal", "Orosz", "Kelemen", "Fazekas", "Boros", "Sándor", "Váradi", "Katona", "Jakab", "Bogdán", "László", "Király", "Biró", "Balog*", "Gulyás", "Lukács", "Magyar", "Sipos", "Szalai", "Pintér", "Fodor", "Kocsis", "Orsós", "Szűcs", "Kis", "Gál", "Balázs", "Fehér", "Török", "Szilágyi", "Fekete", "Rácz", "Simon", "Mészáros", "Oláh", "Juhász", "Takács", "Papp", "Lakatos", "Farkas", "Balogh", "Németh", "Molnár", "Kiss", "Varga", "Horváth", "Szabó", "Tóth", "Kovács", "Nagy" };
        private static string[] forenames = {"Bence","Anna","Máté","Boglárka","Levente","Réka","Dávid","Hanna","Balázs","Zsófia","Dániel","Lili","Ádám","Viktória","Péter","Petra","Bálint","Eszter","Tamás","Laura","Gergő","Nóra","Milán","Dóra","Zsombor","Vivien","Márk","Luca","Dominik","Jázmin","Kristóf","Fanni","László","Dorina","Marcell","Csenge","Zoltán","Gréta","Botond","Sára","András","Alexandra","Ákos","Noémi","Gábor","Lilla","Attila","Virág","Martin","Panna","Barnabás","Bianka","Krisztián","Rebeka","Patrik","Emma","Roland","Kitti","Áron","Barbara","István","Nikolett","Márton","Flóra","Zsolt","Kata","Szabolcs","Tímea","Csaba","Vanessza","Kevin","Kinga","Richárd","Emese","Zalán","Liliána","János","Regina","József","Enikő","Benedek","Dorka","Olivér","Vanda","Sándor","Ramóna","Gergely","Krisztina","Róbert","Blanka","Erik","Amanda","Ferenc","Adrienn","Alex","Janka","Norbert","Fruzsina","Viktor","Szonja","Tibor","Lara","Benjámin","Júlia","Csanád","Dzsenifer","Mátyás","Zoé","Bendegúz","Maja","Kornél","Veronika","Noel","Zsanett","Ábel","Cintia","Csongor","Míra","Mihály","Tamara","Imre","Kíra","Krisztofer","Dorottya","Hunor","Kamilla","Zétény","Zita","Miklós","Evelin","Nándor","Katalin","Adrián","Alexa","György","Dominika","Boldizsár","Brigitta","Vilmos","Diána","Ármin","Klaudia","Lajos","Kincső","Szilárd","Borbála","Gyula","Orsolya","Károly","Zsuzsanna","Vince","Bernadett","Árpád","Adél","Soma","Nikoletta","Domonkos","Anita","Márkó","Mercédesz","Szebasztián","Izabella","Barna","Léna","Béla","Andrea","Brendon","Renáta","Donát","Patrícia","Bertalan","Natália","Álmos","Lilien","Rikárdó","Mira","Ágoston","Melinda","Pál","Gabriella","Simon","Emília","Andor","Mária","Kende","Szilvia","Nikolasz","Bettina","Renátó","Johanna","Alexander","Melissza","Nimród","Ágnes","Dénes","Dalma","Benjamin","Tifani","Koppány","Éva"};
        private static string[] domains = { "email.com", "email.hu", "elevel.hu", "mail.hu" };
        private static Random rand = new Random();

        private static Dictionary<char, char> charPairs = new Dictionary<char, char>()
        {
            { 'á', 'a' },
            { 'Á', 'A' },
            { 'é', 'e' },
            { 'É', 'E' },
            { 'í', 'i' },
            { 'Í', 'I' },
            { 'ó', 'o' },
            { 'Ó', 'O' },
            { 'ö', 'o' },
            { 'Ö', 'O' },
            { 'ő', 'o' },
            { 'Ő', 'O' },
            { 'ú', 'u' },
            { 'Ú', 'U' },
            { 'ü', 'u' },
            { 'Ü', 'U' },
            { 'ű', 'u' },
            { 'Ű', 'U' }
        };

        public static string GenerateRandomEmail()
        {
            var lastName = lastnames[rand.Next(lastnames.Length)];
            var foreName = forenames[rand.Next(forenames.Length)];
            var domain = domains[rand.Next(domains.Length)];
            if (domain.EndsWith(".hu"))
                return $"{RemoveAccent(lastName.ToLower())}.{RemoveAccent(foreName.ToLower())}@{domain}";
            else 
                return $"{RemoveAccent(foreName.ToLower())}.{RemoveAccent(lastName.ToLower())}@{domain}";
        }

        private static string RemoveAccent(string value)
        {
            var keys = charPairs.Select(d => d.Key).ToList();
            while (value.Any(c => keys.Contains(c)))
            {
                var ch = value.First(c => keys.Contains(c));
                value = value.Replace(ch, charPairs[ch]);
            }
            return value;
        }

    }
}

