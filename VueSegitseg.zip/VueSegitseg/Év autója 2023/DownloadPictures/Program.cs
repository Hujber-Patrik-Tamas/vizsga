﻿// See https://aka.ms/new-console-template for more information
using DownloadPictures;
using Newtonsoft.Json;
using System.Net;
using System;
using System.Security.Cryptography.X509Certificates;

Console.WriteLine("Hello, World!");

var json = File.ReadAllText("h:\\100 Tanárok\\Bognár Pál\\@cluster.jedlik.eu\\Év autója 2023\\cars.json");
var cars = JsonConvert.DeserializeObject<CarModel[]>(json);
for (int i = 0; i < cars.Length; i++)
{
    Console.WriteLine(cars[i].Model);
    cars[i].Id = i + 1;
    using (WebClient client = new WebClient())
    {
        cars[i].Picture = Convert.ToBase64String(client.DownloadData(new Uri(cars[i].PictureUrl)));
    }
}
File.WriteAllText("h:\\100 Tanárok\\Bognár Pál\\@cluster.jedlik.eu\\Év autója 2023\\cars_new.json", JsonConvert.SerializeObject(cars));

