﻿using Org.BouncyCastle.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Wpf21_butorbolt_mysql.Models;

namespace Wpf21_butorbolt_mysql
{
    /// <summary>
    /// Interaction logic for ButorReszletek.xaml
    /// </summary>
    public partial class ButorReszletek : Window
    {
        List<AlapanyagModel> alapanyagok = new List<AlapanyagModel>();
        public ButorModel butor { get; private set; }

        public ButorReszletek(ButorModel model)
        {
            InitializeComponent();
            butor = new ButorModel();
            butor = model;
            this.DataContext = butor;

            alapanyagok = AlapanyagModel.select();
            CBO_alapanyagok.ItemsSource = alapanyagok;
        }

        private void BTN_ok_Click(object sender, RoutedEventArgs e)
        {
            if (butor.id == 0)
            {
                ButorModel.insert(butor);
            } else
            {
                ButorModel.update(butor);
            }
            DialogResult = true;
            Close();
        }

        private void BTN_megse_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
