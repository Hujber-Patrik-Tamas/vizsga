﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using MySql.Data.MySqlClient;
using System.Configuration;

namespace Wpf21_butorbolt_mysql.Models
{
    public class AlapanyagModel
    {
        public int? id { get; set; }
        public string megnevezes { get; set; }

        public AlapanyagModel(MySqlDataReader reader)
        {
            this.id = Convert.ToInt32(reader["id"]);
            this.megnevezes = reader["megnevezes"].ToString();
        }
        public AlapanyagModel(int? id, string megnevezes)
        {
            this.id = id;
            this.megnevezes = megnevezes;
        }

        public static List<AlapanyagModel> select()
        {
            var lista = new List<AlapanyagModel>();
            using (var con = new MySqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString))
            {
                con.Open();
                var sql = "SELECT * FROM alapanyag";
               
                using (var cmd = new MySqlCommand(sql, con))
                {
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            lista.Add(new AlapanyagModel(reader));
                        }
                    }
                }
            }
            return lista;
        }
    }
}
