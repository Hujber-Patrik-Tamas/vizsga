﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wpf24_ef_one_to_many
{
    internal class IskolaContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySql("Server=localhost;Database=iskolaDemo;Uid=root;Pwd=;",ServerVersion.AutoDetect("Server=localhost;Database=iskolaDemo;Uid=root;Pwd=;"));
        }

        public DbSet<Tanulo> Tanulo { get; set; }
        public DbSet<Osztaly> Osztaly { get; set; }


    }
}
