﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace wpf24_ef_one_to_many
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        IskolaContext IskolaContext = new IskolaContext();
        public MainWindow()
        {
            InitializeComponent();

            //Osztaly osztaly = new Osztaly() { osztalyNev = "14A", osztalyFonok = "Soós Gábor" };
            //IskolaContext.Add<Osztaly>(osztaly);

            //osztaly = new Osztaly() { osztalyNev = "12A", osztalyFonok = "Nits László" };
            //IskolaContext.Add<Osztaly>(osztaly);

            //Tanulo tanulo = new Tanulo() { tanuloNev = "Józsi", szuletesiDatum = DateOnly.Parse("2000.01.01"),osztalyId=1 };
            //IskolaContext.Add<Tanulo>(tanulo);
            //tanulo = new Tanulo() { tanuloNev = "Béla", szuletesiDatum = DateOnly.Parse("2001.01.01"), osztalyId = 1 };
            //IskolaContext.Add<Tanulo>(tanulo);

            //tanulo = new Tanulo() { tanuloNev = "Péter", szuletesiDatum = DateOnly.Parse("2002.01.01"), osztalyId = 2 };
            //IskolaContext.Add<Tanulo>(tanulo);
            //tanulo = new Tanulo() { tanuloNev = "Kata", szuletesiDatum = DateOnly.Parse("2002.02.01"), osztalyId = 2 };
            //IskolaContext.Add<Tanulo>(tanulo);
            //tanulo = new Tanulo() { tanuloNev = "Imre", szuletesiDatum = DateOnly.Parse("2002.01.01"), osztalyId = 2 };
            //IskolaContext.Add<Tanulo>(tanulo);

            //IskolaContext.SaveChanges();

            IskolaContext.Tanulo.Load();
            IskolaContext.Osztaly.Load();

            DG_tanulok.ItemsSource = IskolaContext.Tanulo.Local.ToObservableCollection();
            DG_osztaly.ItemsSource = IskolaContext.Osztaly.Local.ToObservableCollection();

            var o = IskolaContext.Osztaly.Local.OrderBy(x => x.osztalyNev).ToList();
            o.Insert(0, new Osztaly() { osztalyId = 0, osztalyNev = "Kérem válasszon!" });
            CBO_osztalyok.SelectedIndex = 0;
            CBO_osztalyok.ItemsSource = o;
        }

        private void CBO_osztalyok_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var tanulok = (from t in IskolaContext.Tanulo
                           where t.Osztaly.osztalyNev == ((Osztaly)CBO_osztalyok.SelectedItem).osztalyNev
                           select new { t.tanuloNev, t.szuletesiDatum, t.Osztaly.osztalyNev }
                           ).ToList();
            DG_lekerdezes.ItemsSource = tanulok;
        }
    }
}
