﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wpf24_ef_one_to_many
{
    internal class Osztaly
    {
        [Key]
        public int osztalyId { get; set; }

        [Required]
        public string? osztalyNev { get; set; }

        public string? osztalyFonok { get; set; }

        // kapcsolat
        public ICollection<Tanulo> Tanulo { get; set; }

    }
}
