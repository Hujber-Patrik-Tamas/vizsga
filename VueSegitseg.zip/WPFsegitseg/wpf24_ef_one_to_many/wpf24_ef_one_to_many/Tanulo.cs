﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wpf24_ef_one_to_many
{
    internal class Tanulo
    {
        [Key]
        public int tanuloId { get; set; }
        public string tanuloNev { get; set; }
        public DateOnly szuletesiDatum { get; set; }


        // kapcsolat
        public int osztalyId { get; set; } // név egyezés
        public Osztaly Osztaly { get; set; }
    }
}
