﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wpf25_ef_many_to_many
{
    internal class IskolaContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySql("Server=localhost;Database=14a_iskola;Uid=root;Pwd=;", ServerVersion.AutoDetect("Server=localhost;Database=14a_iskola;Uid=root;Pwd=;"));
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TesztEredmenyek>().HasKey(te => new { te.tanuloId, te.tesztId });
        }

        public DbSet<Tanulo> Tanulo { get; set; }
        public DbSet<Teszt> Teszt { get; set; }
        public DbSet<TesztEredmenyek> TesztEredmenyek { get; set; }


    }
}
