﻿using Microsoft.EntityFrameworkCore;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace wpf25_ef_many_to_many
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        IskolaContext context  = new  IskolaContext();

        public MainWindow()
        {
            InitializeComponent();

            //context.Add<Tanulo>(new Tanulo() {tanuloNev = "Béla", szuletesiDatum = DateOnly.Parse("2000.01.01") });
            //context.Add<Tanulo>(new Tanulo() {tanuloNev = "Józsi", szuletesiDatum = DateOnly.Parse("2001.04.04") });
            //context.Add<Tanulo>(new Tanulo() {tanuloNev = "Kata", szuletesiDatum = DateOnly.Parse("2002.02.01") });
            //context.Add<Tanulo>(new Tanulo() {tanuloNev = "Péter", szuletesiDatum = DateOnly.Parse("2002.02.01") });

            //context.Add<Teszt>(new Teszt() { tesztMegnevezes = "C# alapok" });
            //context.Add<Teszt>(new Teszt() { tesztMegnevezes = "EF haladó" });
            //context.Add<Teszt>(new Teszt() { tesztMegnevezes = "Adatbázis kezelés" });

            //context.SaveChanges();


            context.Tanulo.Load();
            context.Teszt.Load();
            context.TesztEredmenyek.Load();

            DG_eredmenyek.ItemsSource = context.TesztEredmenyek.Local.ToObservableCollection();

            CBO_tanulok.ItemsSource = context.Tanulo.Local.ToObservableCollection();
            CBO_teszt.ItemsSource = context.Teszt.Local.ToObservableCollection();
        }

        private void BTN_mentes_Click(object sender, RoutedEventArgs e)
        {
            var tanulo = (Tanulo)CBO_tanulok.SelectedItem;
            var teszt = (Teszt)CBO_teszt.SelectedItem;
            var eredmeny = int.Parse(TB_eredmeny.Text);
            var datum = DP_datum.SelectedDate;

            context.TesztEredmenyek.Add(new TesztEredmenyek() { Tanulo = tanulo, Teszt = teszt, datum =  datum, eredmeny=eredmeny   });
            context.SaveChanges();
        }
    }
}
