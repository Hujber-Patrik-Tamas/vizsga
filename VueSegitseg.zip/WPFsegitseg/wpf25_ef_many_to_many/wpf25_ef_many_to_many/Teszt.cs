﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wpf25_ef_many_to_many
{
    internal class Teszt
    {
        [Key]
        public int tesztId { get; set; }

        [Required]
        [StringLength(200)]
        public string tesztMegnevezes { get; set; }

        public ICollection<TesztEredmenyek> TesztEredmenyek { get; set; }
    }
}
