﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wpf26_asztalfoglalas
{
    // egy oldal
    internal class Asztal
    {
        [Key]
        public int id { get; set; }

        [Required]
        [StringLength(50)]
        public string megnevezes { get; set; }

        public int ferohely { get; set; }

    }
}
