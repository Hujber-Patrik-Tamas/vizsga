﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;

using Microsoft.EntityFrameworkCore;

namespace wpf26_asztalfoglalas
{
    internal class AsztalfoglalasContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySql("server=localhost;database=14a_asztalfoglalas;uid=root;pwd=;", ServerVersion.AutoDetect("server=localhost;database=14a_asztalfoglalas;uid=root;pwd=;"));
        }

        public DbSet<Asztal> Asztal { get; set; }
        public DbSet<Foglalas> Foglalas { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Asztal>().HasData(
                new Asztal() {id=1, megnevezes="1-es asztal", ferohely=4 },
                new Asztal() {id=2, megnevezes="2-es asztal", ferohely=2 },
                new Asztal() {id=3, megnevezes="3-es asztal", ferohely=6 },
                new Asztal() {id=4, megnevezes="4-es asztal", ferohely=8 },
                new Asztal() {id=5, megnevezes="5-es asztal", ferohely=2 }
                );

            modelBuilder.Entity<Foglalas>(f =>
            {
                f.HasData(
                    new Foglalas() { id = 1, asztalId = 1, nev = "Béla", telefonszam = "0620...", datum = DateTime.Parse("2023.03.10"), letszam = 4 },
                    new Foglalas() { id = 2, asztalId = 3, nev = "Józsi", telefonszam = "0620...", datum = DateTime.Parse("2023.03.11"), letszam = 5 }
                    );
            });
        }
    }
}
