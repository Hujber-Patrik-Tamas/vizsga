﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wpf26_asztalfoglalas
{
    // több oldal
    internal class Foglalas
    {
        [Key]
        public int id { get; set; }

        [Required]
        [StringLength(100)]
        public string nev { get; set; }

        [StringLength(30)]
        public string telefonszam { get; set; }

        public int letszam { get; set; }

        public DateTime datum { get; set; }

        // kapcsolat
        [Required]
        public Asztal Asztal { get; set; }

        [Required]
        public int asztalId { get; set; } // idegen kulcs
    }
}
