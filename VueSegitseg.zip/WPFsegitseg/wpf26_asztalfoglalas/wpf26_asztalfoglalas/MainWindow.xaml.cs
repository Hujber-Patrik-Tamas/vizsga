﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using Microsoft.EntityFrameworkCore;

namespace wpf26_asztalfoglalas
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        AsztalfoglalasContext context = new AsztalfoglalasContext();
        public MainWindow()
        {
            InitializeComponent();

            setStatus(true);

            context.Foglalas.Load();
            context.Asztal.Load();

            DG_lista.ItemsSource = context.Foglalas.Local.ToObservableCollection();

            CBO_asztal.ItemsSource = context.Asztal.Local.ToObservableCollection();
            CBO_asztal.DisplayMemberPath = "megnevezes";


        }

        private void BTN_uj_Click(object sender, RoutedEventArgs e)
        {
            setStatus(false);
            GRD_adatok.DataContext = new Foglalas() { datum = DateTime.Today };
        }

        private void BTN_modositas_Click(object sender, RoutedEventArgs e)
        {
            if (DG_lista.SelectedItem != null)
            {
                setStatus(false);
            }
        }

        private void BTN_torles_Click(object sender, RoutedEventArgs e)
        {
            if (DG_lista.SelectedItem != null)
            {
                Foglalas f = (Foglalas)GRD_adatok.DataContext;
                context.Foglalas.Remove(f);
                context.SaveChanges();
            }
        }

        private void DG_lista_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            GRD_adatok.DataContext = DG_lista.SelectedItem;
        }

        private void BTN_mentes_Click(object sender, RoutedEventArgs e)
        {
            Foglalas f = (Foglalas)GRD_adatok.DataContext;
            if (f.id == 0)
            {
                context.Foglalas.Add(f);  // local dbset
            } else
            {
                context.Entry(f).State = EntityState.Modified;
            }

            context.SaveChanges(); // database update
            setStatus(true);
            DG_lista.SelectedItem = f;
        }

        private void BTN_megse_Click(object sender, RoutedEventArgs e)
        {
            Foglalas f = (Foglalas)GRD_adatok.DataContext;
            if (f.id !=0)
            {
                context.Entry(f).State = EntityState.Unchanged;
                DG_lista.Items.Refresh();
            }
            setStatus(true);
            DG_lista.SelectedItem = null;
            GRD_adatok.DataContext = null;
        }

        private void setStatus(bool melyik)
        {
            DG_lista.IsEnabled = melyik;
            SP_gombok.IsEnabled = melyik;

            GRD_adatok.IsEnabled = !melyik;
        }
    }
}
