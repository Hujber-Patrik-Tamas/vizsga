﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace wpf26asztalfoglalas.Migrations
{
    /// <inheritdoc />
    public partial class letszamasztaladat : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "letszam",
                table: "Foglalas",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.InsertData(
                table: "Asztal",
                columns: new[] { "id", "ferohely", "megnevezes" },
                values: new object[,]
                {
                    { 1, 4, "1-es asztal" },
                    { 2, 2, "2-es asztal" },
                    { 3, 6, "3-es asztal" },
                    { 4, 8, "4-es asztal" },
                    { 5, 2, "5-es asztal" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Asztal",
                keyColumn: "id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Asztal",
                keyColumn: "id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Asztal",
                keyColumn: "id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Asztal",
                keyColumn: "id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Asztal",
                keyColumn: "id",
                keyValue: 5);

            migrationBuilder.DropColumn(
                name: "letszam",
                table: "Foglalas");
        }
    }
}
