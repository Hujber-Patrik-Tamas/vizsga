﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace wpf26asztalfoglalas.Migrations
{
    /// <inheritdoc />
    public partial class foglalasadat : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Foglalas",
                columns: new[] { "id", "asztalId", "datum", "letszam", "nev", "telefonszam" },
                values: new object[,]
                {
                    { 1, 1, new DateTime(2023, 3, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), 4, "Béla", "0620..." },
                    { 2, 3, new DateTime(2023, 3, 11, 0, 0, 0, 0, DateTimeKind.Unspecified), 5, "Józsi", "0620..." }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Foglalas",
                keyColumn: "id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Foglalas",
                keyColumn: "id",
                keyValue: 2);
        }
    }
}
