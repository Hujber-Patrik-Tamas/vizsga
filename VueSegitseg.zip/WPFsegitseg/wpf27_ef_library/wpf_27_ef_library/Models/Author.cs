﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace wpf_27_ef_library.Models;

public partial class Author
{
    public int AuthorId { get; set; }

    public string? Name { get; set; }

    public string? Surname { get; set; }

    public virtual ICollection<Book> Books { get; } = new List<Book>();


    // saját tulajdonság
    [NotMapped]
    public string Fullname { get { return string.Format("{0} {1}", Name, Surname); }  }
}
