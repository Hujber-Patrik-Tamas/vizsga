﻿using System;
using System.Collections.Generic;

namespace wpf_27_ef_library.Models;

public partial class Book
{
    public int BookId { get; set; }

    public string? Name { get; set; }

    public int? Pagecount { get; set; }

    public int? Point { get; set; }

    public int? AuthorId { get; set; }

    public int? TypeId { get; set; }

    public virtual Author? Author { get; set; }

    public virtual ICollection<Borrow> Borrows { get; } = new List<Borrow>();

    public virtual Types? Types { get; set; }
}
