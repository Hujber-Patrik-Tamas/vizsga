﻿using System;
using System.Collections.Generic;

namespace wpf_27_ef_library.Models;

public partial class Types
{
    public int TypeId { get; set; }

    public string? Name { get; set; }

    public virtual ICollection<Book> Books { get; } = new List<Book>();
}
