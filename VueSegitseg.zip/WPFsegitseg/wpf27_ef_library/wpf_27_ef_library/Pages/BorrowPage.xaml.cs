﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using wpf_27_ef_library.Models;

namespace wpf_27_ef_library.Pages
{
    /// <summary>
    /// Interaction logic for BorrowPage.xaml
    /// </summary>
    public partial class BorrowPage : Page
    {
        _14aLibraryContext context = new _14aLibraryContext();

        public BorrowPage()
        {
            InitializeComponent();

            context.Students.Load();
            context.Authors.Load();
            context.Books.Load();

            CBO_osztaly.ItemsSource = (from o in context.Students
                                       select o.Class).ToList().Distinct().OrderBy(x => x);
            CBO_osztaly.SelectedIndex = 0;

            //LB_tanulok.ItemsSource = context.Students.Local.ToObservableCollection();
            CBO_szerzok.ItemsSource = context.Authors.Local.ToObservableCollection();
            CBO_szerzok.SelectedIndex = 0;
        }

        private void CBO_osztaly_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            tanuloSzures();
        }

        

        private void TB_kereses_TextChanged(object sender, TextChangedEventArgs e)
        {
            tanuloSzures();
        }

        private void tanuloSzures()
        {
            var tanuloLista = (from t in context.Students
                               where t.Class == (string)CBO_osztaly.SelectedItem && 
                               (t.Name.Contains(TB_kereses.Text) || t.Surname.Contains(TB_kereses.Text))
                               orderby t.Name, t.Surname
                               select t).ToList();
            LB_tanulok.ItemsSource = tanuloLista;
        }

        private void CBO_szerzok_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            LB_konyvek.ItemsSource = (from b in context.Books
                                      where b.AuthorId == ((Author)CBO_szerzok.SelectedItem).AuthorId
                                      select b
                                      ).ToList();
        }

        private void BTN_kolcsonoz_Click(object sender, RoutedEventArgs e)
        {
            Borrow kolcsonzes = new Borrow() {
                BookId = ((Book)LB_konyvek.SelectedItem).BookId,
                StudentId = ((Student)LB_tanulok.SelectedItem).StudentId,
                BroughtDate = DP_kiadva.SelectedDate,
                TakenDate = DateTime.Now
            };
            context.Add<Borrow>(kolcsonzes);
            context.SaveChanges();
            konyvSzures();
        }

        private void LB_tanulok_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (LB_tanulok.SelectedItem != null)
            {
                konyvSzures();
            }
        }

        private void konyvSzures()
        {
            LB_kolcsonzottKonyvek.ItemsSource = (from k in context.Borrows
                                                 where k.StudentId == ((Student)LB_tanulok.SelectedItem).StudentId
                                                 select new
                                                 {
                                                     k.BorrowId,
                                                     k.Book.Name,
                                                     k.Book.Author.Fullname,
                                                     datum = string.Format("{0:yyyy.MM.dd} - {1:yyyy.MM.dd}", k.TakenDate, k.BroughtDate)
                                                 }).ToList();
        }
    }
}
