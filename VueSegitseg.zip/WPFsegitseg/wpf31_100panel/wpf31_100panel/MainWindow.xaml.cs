﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace wpf31_100panel
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Grid sajatRacs = new Grid();

        public MainWindow()
        {
            InitializeComponent();

            urlapgeneralas();
        }

        private void urlapgeneralas()
        {
            ablak.Width = 500;
            ablak.Height = 500;
            ablak.Title = "Mátrix";

            sajatRacs.ShowGridLines = false;

            for (int i = 0; i < 10; i++)
            {
                ColumnDefinition oszlop = new ColumnDefinition();
                oszlop.Width = new GridLength(1, GridUnitType.Star);
                sajatRacs.ColumnDefinitions.Add(oszlop);

                RowDefinition sor = new RowDefinition();
                sor.Height = new GridLength(1, GridUnitType.Star);
                sajatRacs.RowDefinitions.Add(sor);  
            }

            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    Border keret = new Border();
                    keret.Background = Brushes.Blue;
                    keret.Margin = new Thickness(2);
                    keret.Name = "k_" + i + "_" + j;
                    keret.MouseDown += new MouseButtonEventHandler(gombKattintas);

                    Grid.SetRow(keret, i);
                    Grid.SetColumn(keret, j);

                    sajatRacs.Children.Add(keret);
                }
            }

            ablak.Content = sajatRacs;

        }

        private void gombKattintas(object sender, MouseButtonEventArgs e)
        {
            Border b = sender as Border;

            string[] koordinata = b.Name.Split('_');
            int sor = int.Parse(koordinata[1]);
            int oszlop = int.Parse(koordinata[2]);

            var sg = sajatRacs.Children;

            for (int i = 0; i < 10; i++)
            {
                // sor 
                string nev = "k_" + sor + "_" + i;
                var k = (from x in sg.OfType<Border>()
                        where x.Name == nev
                        select x).SingleOrDefault();
                if (k.Background == Brushes.Blue)
                {
                    k.Background = Brushes.Red;
                } else
                {
                    k.Background = Brushes.Blue;
                }

            }

        }
    }
}
