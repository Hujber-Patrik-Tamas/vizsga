﻿using System;
using System.Collections.Generic;

namespace wpf32_ostermelo.Models;

public partial class Gyumolcslevek
{
    public int Id { get; set; }

    public string Gynev { get; set; } = null!;

    public virtual ICollection<Kiszallitasok> Kiszallitasoks { get; } = new List<Kiszallitasok>();
}
