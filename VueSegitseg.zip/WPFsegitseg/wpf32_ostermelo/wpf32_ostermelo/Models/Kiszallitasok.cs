﻿using System;
using System.Collections.Generic;

namespace wpf32_ostermelo.Models;

public partial class Kiszallitasok
{
    public int Sorsz { get; set; }

    public int Gyumleid { get; set; }

    public int Partnerid { get; set; }

    public DateOnly Datum { get; set; }

    public int Karton { get; set; }

    public virtual Gyumolcslevek Gyumle { get; set; } = null!;

    public virtual Partnerek Partner { get; set; } = null!;
}
