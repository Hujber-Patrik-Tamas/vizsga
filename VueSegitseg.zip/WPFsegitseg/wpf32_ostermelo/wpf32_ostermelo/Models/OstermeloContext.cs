﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace wpf32_ostermelo.Models;

public partial class OstermeloContext : DbContext
{
    public OstermeloContext()
    {
    }

    public OstermeloContext(DbContextOptions<OstermeloContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Gyumolcslevek> Gyumolcsleveks { get; set; }

    public virtual DbSet<Kiszallitasok> Kiszallitasoks { get; set; }

    public virtual DbSet<Partnerek> Partnereks { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)

        => optionsBuilder.UseMySql("server=localhost;database=ostermelo;uid=root", Microsoft.EntityFrameworkCore.ServerVersion.Parse("10.4.24-mariadb"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .UseCollation("utf8mb4_general_ci")
            .HasCharSet("utf8mb4");

        modelBuilder.Entity<Gyumolcslevek>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("gyumolcslevek");

            entity.Property(e => e.Id)
                .HasColumnType("int(11)")
                .HasColumnName("id");
            entity.Property(e => e.Gynev)
                .HasMaxLength(16)
                .HasColumnName("gynev");
        });

        modelBuilder.Entity<Kiszallitasok>(entity =>
        {
            entity.HasKey(e => e.Sorsz).HasName("PRIMARY");

            entity.ToTable("kiszallitasok");

            entity.HasIndex(e => e.Gyumleid, "gyumleid");

            entity.HasIndex(e => e.Partnerid, "partnerid");

            entity.Property(e => e.Sorsz)
                .HasColumnType("int(11)")
                .HasColumnName("sorsz");
            entity.Property(e => e.Datum).HasColumnName("datum");
            entity.Property(e => e.Gyumleid)
                .HasColumnType("int(11)")
                .HasColumnName("gyumleid");
            entity.Property(e => e.Karton)
                .HasColumnType("int(11)")
                .HasColumnName("karton");
            entity.Property(e => e.Partnerid)
                .HasColumnType("int(11)")
                .HasColumnName("partnerid");

            entity.HasOne(d => d.Gyumle).WithMany(p => p.Kiszallitasoks)
                .HasForeignKey(d => d.Gyumleid)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("kiszallitasok_ibfk_1");

            entity.HasOne(d => d.Partner).WithMany(p => p.Kiszallitasoks)
                .HasForeignKey(d => d.Partnerid)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("kiszallitasok_ibfk_2");
        });

        modelBuilder.Entity<Partnerek>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("partnerek");

            entity.Property(e => e.Id)
                .HasColumnType("int(11)")
                .HasColumnName("id");
            entity.Property(e => e.Kontakt)
                .HasMaxLength(20)
                .HasColumnName("kontakt");
            entity.Property(e => e.Telepules)
                .HasMaxLength(20)
                .HasColumnName("telepules");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
