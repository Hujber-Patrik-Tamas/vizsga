﻿using System;
using System.Collections.Generic;

namespace wpf32_ostermelo.Models;

public partial class Partnerek
{
    public int Id { get; set; }

    public string Kontakt { get; set; } = null!;

    public string Telepules { get; set; } = null!;

    public virtual ICollection<Kiszallitasok> Kiszallitasoks { get; } = new List<Kiszallitasok>();
}
